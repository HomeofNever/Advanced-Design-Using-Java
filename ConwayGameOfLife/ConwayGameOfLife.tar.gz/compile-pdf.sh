pandoc header-includes.yaml manuals/manual.md -o manuals/manual.pdf --pdf-engine=lualatex
pandoc header-includes.yaml manuals/tests.md -o manuals/tests.pdf --pdf-engine=lualatex