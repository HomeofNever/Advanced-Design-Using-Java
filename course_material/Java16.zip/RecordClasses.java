public class RecordClasses {
    public static void main(String args[]) {
        CompareNumRecord num = new CompareNumRecord(1);
        System.out.println("x: " + num.x());
        System.out.println(".toString(): " + num.toString());

        CompareNumRecord num2 = new CompareNumRecord(1);
        System.out.println("Hash code 1: " + num.hashCode());
        System.out.println("Hash code 2: " + num2.hashCode());
        System.out.println("Equals evaluation: " + num.equals(num2));
        System.out.println();

        Rational rat = new Rational(3, 12);
        System.out.println(rat);
        System.out.println(rat.formatted());
        System.out.println();

        Tuple<String, Integer> tuple = new Tuple<String, Integer>("One", 1);
        System.out.println(tuple);
    }

    public static int gcd(int num, int denom) {
        if (num == denom)
            return num;
        else if (num > denom)
            return gcd(num - denom, denom);
        else
            return gcd(num, denom - num);
    }
}

record CompareNumRecord(int x) { }

record Rational(int num, int denom) {
    Rational {
        int gcd = RecordClasses.gcd(num, denom);
        num /= gcd;
        denom /= gcd;
    }
    public String formatted() {
        return "" + num + "/" + denom;
    }
}

record Tuple<K,T>(K first, T second) { }