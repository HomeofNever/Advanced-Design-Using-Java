public class PatternMatching {
    public static void main(String args[]) {
        CompareNumOld old1 = new CompareNumOld(1);
        CompareNumOld old2 = new CompareNumOld(1);
        CompareNumNew new1 = new CompareNumNew(2);
        CompareNumNew new2 = new CompareNumNew(2);

        System.out.println("Old style equals: " + old1.equals(old2));
        System.out.println("New style equals: " + new1.equals(new2));
    }
}

class CompareNumOld {
    private final int x;

    public CompareNumOld(int x) {
        this.x = x;
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof CompareNumOld))
            return false;
        CompareNumOld other = (CompareNumOld) o;
        return this.x == other.x;
    }
}

class CompareNumNew {
    private final int x;

    public CompareNumNew(int x) {
        this.x = x;
    }

    @Override
    public boolean equals(Object o) {
        return (o instanceof CompareNumNew other)
               && this.x == other.x;
    }
}