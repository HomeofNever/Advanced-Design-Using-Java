@RequestForEnhancement(
	id = 12345,
	synopsis = "Enable additional functionality",
	//developer = "Kuzmin, K.",
	date = "4/28/2021"
)
public class AnnotationDemo {

	// @RequestForEnhancement(
		// id = 12346,
		// synopsis = "Other feature"
	// )
	public int m() {
		return 0;
	}

	@Copyright("(c) 2021 RPI")
	public void m2() {

	}
	
}