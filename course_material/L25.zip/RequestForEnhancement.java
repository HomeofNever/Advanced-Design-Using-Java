import java.lang.annotation.*;

@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface RequestForEnhancement {
	int id();
	String synopsis();
	String developer() default "[unassigned]";
	String date() default "[unkonwn]";
}