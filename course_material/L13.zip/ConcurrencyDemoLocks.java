import java.util.logging.*;
import java.util.concurrent.locks.*;

public class ConcurrencyDemoLocks {
	public static void main(String[] args) {
		FileHandler handler;
		
		try {
			handler = new FileHandler();
		}
		catch (Exception e) { return; }
		handler.setFormatter(new SimpleFormatter());
		Logger.getLogger("global").addHandler(handler);
		Logger.getLogger("global").info("Starting main thread: " + Thread.currentThread().getId());
		
		StringBuffer str = new StringBuffer("Sample string: ");
		Lock lock = new ReentrantLock();
		Thread t1 = new Thread(new MyThread(str, lock));
		t1.start();
		try {
			Thread.sleep(100);
		}
		catch (Exception e) { }
		
		Thread t2 = new Thread(new MyThread(str, lock));
		t2.start();
		
		/*Thread t3 = new Thread(new MyThread(str));
		t3.start();
		
	    Thread t4 = new Thread(new MyThread(str));
		t4.start();
		
	    Thread t5 = new Thread(new MyThread(str));
		t5.start();
		
	    Thread t6 = new Thread(new MyThread(str));
		t6.start();*/
		
		Logger.getLogger("global").info("Waiting for joining with t1");
		try {t1.join();} catch (Exception e) {}
		Logger.getLogger("global").info("Waiting for joining with t2");
		try {t2.join();} catch (Exception e) {}
		/*Logger.getLogger("global").info("Waiting for joining with t3");
		try {t3.join();} catch (Exception e) {}
		Logger.getLogger("global").info("Waiting for joining with t4");
		try {t4.join();} catch (Exception e) {}
		Logger.getLogger("global").info("Waiting for joining with t5");
		try {t5.join();} catch (Exception e) {}
		Logger.getLogger("global").info("Waiting for joining with t6");
		try {t6.join();} catch (Exception e) {}*/
		Logger.getLogger("global").info(str.toString());
		Logger.getLogger("global").info("Ended main thread");

		handler.close();
	}
}

class MyThread implements Runnable {
	public MyThread(StringBuffer str, Lock lock) {
		this.string = str;
		this.lock = lock; // new ReentrantLock(); // lock
	}
	
	@Override
	public void run() {
		long threadId = Thread.currentThread().getId();
		Logger.getLogger("global").info("Started thread number: " + threadId);
		for (int i = 0; i < 20; i++) { // 2000 20 5
			lock.lock();
			try {
				string.append(" ");
				try {Thread.sleep(100); } catch (Exception e) {}
				string.append(threadId);
				try {Thread.sleep(100); } catch (Exception e) {}			
				string.append(":");
				try {Thread.sleep(100); } catch (Exception e) {}
				string.append(counter++);
			}
			finally {
				lock.unlock();
			}
		}
		Logger.getLogger("global").info("Ended thread number: " + threadId);
	}
	
	private StringBuffer string;
	private Lock lock;
	private long counter;
}