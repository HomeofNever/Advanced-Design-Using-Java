#!/bin/bash
# Don't forget to "chmod ugo+x ./L03.sh"
# bash scripting tutorial: https://www.tutorialkart.com/bash-shell-scripting/
# This is a comment

javac -encoding UTF-16 L05.java
java L05
