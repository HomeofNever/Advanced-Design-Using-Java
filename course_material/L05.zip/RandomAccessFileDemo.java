import java.util.*;
import java.io.*;
import java.nio.file.*;

/**
* RandomAccessFile Demo code for Lecture 5
* @author Konstantin Kuzmin
* @version <b>1.0</b> rev. 0
*/
public class RandomAccessFileDemo
{
   /**
   * main() method
   * @param args - command line arguments
   * @exception FileNotFoundException If file is not found
   * @exception IOException If some I/O issue occurred
   */
   public static void main\u0028String[] args) throws FileNotFoundException, IOException
   {
      String inFileName, outFileName;
      String line;
      
      System.out.println("RandomAccessFile");
      System.out.println("================");
      
      Scanner in = new Scanner(System.in);
      System.out.print("Enter file name: ");
      inFileName = in.nextLine();
      
      RandomAccessFile file = new RandomAccessFile(inFileName, "rw");
      System.out.printf("File length is %d bytes\n", file.length());
      byte b;
      try {
		  while (true) {
		  	  //System.out.printf("%c", file.readChar());
		  	  b = file.readByte();
		  	  System.out.printf("%c", b);
		  	  if (b == '4') {
		  	  	  b = file.readByte();
		  	  	  System.out.printf("%c", b);
		  	  	  if (b == '2') {
		  	  	  	  System.out.println("\n*** Found 42, replacing with 24 ***");
		  	  	  	  file.seek(file.getFilePointer() - 2);
		  	  	  	  file.writeByte('2');
		  	  	  	  file.writeByte('4');
		  	  	  	  file.seek(file.getFilePointer() - 2);
		  	  	  	  System.out.printf("Re-reading the written value: %c%c\n",
		  	  	  	  	  file.readByte(), file.readByte());
		  	  	  }
		  	  }
		  }
      }
      catch (EOFException e) {
      	  System.out.println("Done reading/updating the file.");
      }
      catch (IOException e) {
      	  System.out.println("An I/O exception encountered.");
      }
      finally {
      	  file.close();
      }
      System.out.printf("Reading file %s again:\n", inFileName);
      file = new RandomAccessFile(inFileName, "r");
      while (file.getFilePointer() < file.length()) {
      	  System.out.println(file.readLine());
      }
      file.close();
   }
}
