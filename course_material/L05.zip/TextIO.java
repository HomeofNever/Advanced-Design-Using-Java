import java.io.*;
import java.nio.charset.*;

public class TextIO {
    public static void main(String [] args) {

        // The name of the file to open.
        String fileName = "test_win.txt";
        //String fileName = "test_win_UTF-8.txt";
        //String fileName = "test_nix.txt";
        //String fileName = "test_UTF-16_BOM_LE_win.txt";
        //String fileName = "test_UTF-16_BOM_BE_win.txt";
        //String fileName = "test_UTF-16_no_BOM_BE_win.txt";
        //String fileName = "test_UTF-16_BOM_BE_nix.txt";

        // This will reference one line at a time
        String line = null;

        int counter = 0;
        FileReader fileReader = null;
        BufferedReader bufferedReader = null;
        try {
            // FileReader reads text files in the default encoding.
            fileReader = new FileReader(fileName);
            // Always wrap FileReader in BufferedReader.
            bufferedReader = new BufferedReader(fileReader);

            while((line = bufferedReader.readLine()) != null) {
                System.out.printf("%d: %s\n", ++counter, line);
            }   
        }
        catch(FileNotFoundException ex) {
            System.out.println(
                "Unable to open file '" + fileName + "'");
        }
        catch(IOException ex) {
            System.out.println("Error reading file '" + fileName + "'");
            // Or we could just do this:
            // ex.printStackTrace();
        }
        finally {
        	try {
				// Always close files.
				if (bufferedReader != null) bufferedReader.close();
				if (fileReader != null) fileReader.close();
        	}
			catch (IOException ex) {
				System.out.println("Error closing streams");
			}
        }
        
        System.out.println("-------------------------");
        
        InputStream is = null;
        Reader reader = null;
        try {
		    is = new FileInputStream(fileName);
		    reader = new InputStreamReader(is, Charset.forName("UTF-16"));
		    int charRead;
			while ((charRead = reader.read()) != -1) {
				System.out.printf("%c", (char)charRead);
			}
        }
        catch(FileNotFoundException ex) {
           System.out.println(
               "Unable to open file '" + fileName + "'");
        }
        catch(IOException ex) {
           System.out.println("Error reading file '" + fileName + "'");
        }
        finally {
        try {
			reader.close();
			is.close();
		}
		catch (IOException ex) {
			System.out.println("Error closing streams");
		  }
        }
        
        // The name of the file to open.
        fileName = "out.txt";

        FileWriter fileWriter = null;
        BufferedWriter bufferedWriter = null;
        try {
            // Assume default encoding.
            fileWriter = new FileWriter(fileName);

            // Always wrap FileWriter in BufferedWriter.
            bufferedWriter = new BufferedWriter(fileWriter);

            // Note that write() does not automatically
            // append a newline character.
            bufferedWriter.write("Hello there,");
            bufferedWriter.write(" here is some text.");
            bufferedWriter.newLine();
            bufferedWriter.write("We are writing");
            bufferedWriter.write(" the text to the file.");

            // Always close files.
            bufferedWriter.close();
        }
        catch(IOException ex) {
            System.out.println(
                "Error writing to file '" + fileName + "'");
            // Or we could just do this:
            // ex.printStackTrace();
        }
        finally {
        	try {
				// Always close files.
				if (bufferedWriter != null) bufferedWriter.close();
				if (fileWriter != null) fileWriter.close();
        	}
			catch (IOException ex) {
				System.out.println("Error closing streams");
			}
        }
    }
}