/**
 * 
 */
package edu.rpi.csci4963.u19.kuzmik;

import java.io.IOException;

/**
 * @author Konstantin Kuzmin
 *
 */
public interface Connectable {
	public void connect() throws IOException;
	public void send(String message);	
	public String receive();
	public int getPort();
}
