package lec07;

import org.junit.Test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;

public class PuzzleTest{
    @Test
    public void constructTest(){
        Puzzle test;
        try{
            test  = new Puzzle("../puzzles/notafile");
            assertFalse(true);
        }catch (Exception e){
            assertTrue(true);
        }
        try{
            test  = new Puzzle("../puzzles/faulty1.txt");
            assertFalse(true);
        }catch (Exception e){
            assertTrue(true);
        }
        try{
            test  = new Puzzle("../puzzles/faulty2.txt");
            assertFalse(true);
        }catch (Exception e){
            assertTrue(true);
        }
        try{
            test = new Puzzle("../puzzles/Sample.txt");
            char[][] arr = test.stage(0);
            assertEquals(5, arr.length);
            assertEquals(7, arr[0].length);
        }catch (Exception e){
            assertFalse(true);
        }
    }
        
    // public static void main(String args[]){
    //     PuzzleTest tester = new PuzzleTest();
    //     tester.constructTest();
    // }
    
}