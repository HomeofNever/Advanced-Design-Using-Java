package lec07;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Puzzle{
    private char[][] puzzle;
    private int row;
    private int col;

    public Puzzle(String filename) throws Exception{
        try{
            BufferedReader reader = new BufferedReader(new FileReader(filename));
            String line = null;
            Boolean dims = true;
            while ((line = reader.readLine())!=null){
                if(!dims){
                    System.out.print(line);
                }
            }
            reader.close();
        }catch (Exception e){

        }
    }

    public char[][] getArr(){
        char[][] newArr = new char[row][col];
        return newArr;
    }

    public char[][] stage(int round){
        char[][] stageArr = new char[row][col];
        return stageArr; 
    }

    public boolean fewTwo(){
        return false;
    }

    public boolean twoThree(){
        return false;
    }

    public boolean moreThree(){
        return false;
    }

    public boolean deadThree(){
        return false;
    }

}