package lec07;

import java.util.*;

public class Interface{
    public static void main(String[] args) throws Exception {
        Puzzle test = new Puzzle("");
        
        
    }
}