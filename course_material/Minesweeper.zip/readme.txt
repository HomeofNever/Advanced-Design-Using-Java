From http://zetcode.com/tutorials/javagamestutorial/minesweeper/
GutHub repo: https://github.com/janbodnar/Java-Minesweeper-Game