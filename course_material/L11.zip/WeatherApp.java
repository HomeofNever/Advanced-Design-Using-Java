import java.net.*;
import java.io.*;
import java.util.*;

public class WeatherApp {
	public static void main(String[] args) {
		try {
			
			String urlName, appID;
			// Register and request your own App ID from the Web service and insert it here
			appID = "";
			urlName = "http://api.openweathermap.org/data/2.5/weather?zip=12180,us&units=imperial&APPID=" + appID;
			URL url = new URL(urlName);
			URLConnection connection = url.openConnection();
			connection.connect();
			Map<String, List<String>> headers = connection.getHeaderFields();
			String encoding = connection.getContentEncoding();
			if (encoding == null) {
				encoding = "UTF-8";
			}
			try (Scanner in = new Scanner(connection.getInputStream(), encoding))
			{
				while (in.hasNextLine())
				{
					System.out.println(in.nextLine());
				}
			}
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
}