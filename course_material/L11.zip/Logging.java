import java.util.logging.*;
import java.io.*;

public class Logging {
	public static void main(String[] args) throws IOException, SecurityException {
		Logger myLogger = Logger.getGlobal();
		//myLogger.setLevel(Level.OFF);
		//myLogger.setLevel(Level.FINEST);
		//myLogger.setLevel(Level.FINER);
		myLogger.finer("Inside main...");
		//  If you set the logging level to a value finer than INFO, you also need
		//  to change the log handler configuration. The default log handler
		//  suppresses messages below INFO
		//myLogger.config("The config message...");
		A a = new A();
		myLogger.log(Level.INFO, "A object created");
		System.out.println("------------------------------");
		
		
		Logger logger = Logger.getLogger("edu.rpi.csci-4963");
		logger.setLevel(Level.FINER);
		logger.info("Using the edu.rpi.csci-4963 logger...");

		Logger rpiLogger = Logger.getLogger("edu.rpi");
		rpiLogger.setLevel(Level.SEVERE);
		rpiLogger.log(Level.SEVERE, "Using the edu.rpi logger...");
		logger.info("Another instance of using the edu.rpi.csci-4963 logger...");
		logger.logp(Level.INFO, "L12", "logDemo", "Using the logp() method");
		logger.setFilter(new MyFilter());
		logger.info("A short message...");
		logger.info("A very, very, very, very, very long message...");
		
		logger.setUseParentHandlers(false);
		Handler handler = new ConsoleHandler();
		handler.setLevel(Level.FINER);
		logger.addHandler(handler);
		try {
			handler = new FileHandler();
		}
		catch (Throwable t) {
			logger.log(Level.SEVERE, t.getMessage());
			throw t;
		}
		logger.addHandler(handler);
		
		Handler htmlHandler = new FileHandler("%h/java%u.html");
		htmlHandler.setFormatter(new HTMLFormatter());
		logger.addHandler(htmlHandler);

		a.m1(100);
	}
}

class A {
	private Logger myLogger = Logger.getLogger("edu.rpi.csci-4963");
	public void m1(int n) {
		myLogger.info("Using the same logger edu.rpi.csci-4963!");
		myLogger.entering("edu.rpi.csci-4963.lec12.A", "m1", n);
		System.out.println(m2("abc"));
		myLogger.exiting("edu.rpi.csci-4963.lec12.A", "m1");
	}
	
	public int m2(String s) {
		myLogger.entering("edu.rpi.csci-4963.lec12.A", "m2", s);
		myLogger.exiting("edu.rpi.csci-4963.lec12.A", "m2", 0);
		return 0;
	}
}

class MyFilter implements Filter {
	public boolean isLoggable(LogRecord record) {
		return record.getMessage().length() > 20 ? false : true;
	}
}

class HTMLFormatter extends Formatter {
	@Override
	public String getHead(Handler h) {
		return "<h2>" + "Log starts" + "</h2>";
	}
	@Override
	public String getTail(Handler h) {
		return "<h2>" + "Log ends" + "</h2>";
	}
	@Override
	public String format(LogRecord record) {
		return "<p>Logger name: " + record.getLoggerName() + "</p>" +
		  "<p>Message:" + formatMessage(record) + "</p>";
	}
}