import java.io.*;
import java.net.*;
import java.util.*;
import java.util.logging.*;

public class EchoDual
{
   public static void main(String[] args) throws InterruptedException
   {
   	  ServerSocket s = null;
   	  try {
   	  	  s = new ServerSocket(8189);
   	  }
   	  catch (IOException e) {
   	  	  e.printStackTrace();
   	  }
   	  Logger.getGlobal().info("ServerSocket created");
	  Thread serverThread = new Thread (new EchoServer(s));
	  serverThread.start();
	  Logger.getGlobal().info("Server thread started");
	  Thread.sleep(1000);
	  try {
	  	  s.close();
	  }
   	  catch (IOException e) {
   	  	  e.printStackTrace();
   	  }
   	  Logger.getGlobal().info("ServerSocket closed");

   	  try {
   	  	  s = new ServerSocket(8189);
   	  }
   	  catch (IOException e) {
   	  	  e.printStackTrace();
   	  }
   	  Logger.getGlobal().info("ServerSocket created");
	  serverThread = new Thread (new EchoServer(s));
	  serverThread.start();
	  Logger.getGlobal().info("Server thread started");
   }
}

class EchoServer implements Runnable {
	EchoServer(ServerSocket s) {
		this.s = s;
	}
	public void run() {
		Logger.getGlobal().info("Thread " + Thread.currentThread().getId() + " starting");
		Socket incoming = null;
		try
		{
			 // wait for client connection
			 Logger.getGlobal().info("Thread " + Thread.currentThread().getId() + " about to call accept()");
			 try {
			 	 incoming = s.accept();
			 }
			 catch (IOException e) {
			 	 Logger.getGlobal().info("Thread " + Thread.currentThread().getId() + " caught an exception: " + e.getMessage());
			 }
			 finally {
			 	 if (incoming == null) {
			 	 	 Logger.getGlobal().info("Thread " + Thread.currentThread().getId() + " is done");
			 	 	 return;
			 	 }
			 }
			 Logger.getGlobal().info("Thread " + Thread.currentThread().getId() + " returned from accept()");
			 try
			 {
				InputStream inStream = incoming.getInputStream();
				OutputStream outStream = incoming.getOutputStream();
			
				Scanner in = new Scanner(inStream);
				PrintWriter out = new PrintWriter(outStream, true /* autoFlush */);
			
				out.println("Hello! Enter BYE to exit.");
			
				// echo client input
				boolean done = false;
				while (!done && in.hasNextLine())
				{
				   String line = in.nextLine();
				   out.println("Echo: " + line);
				   if (line.trim().equals("BYE")) done = true;
				}
			 }
			 finally
			 {
				incoming.close();
			 }
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		Logger.getGlobal().info("Thread " + Thread.currentThread().getId() + " is done");
	}
	
	private ServerSocket s;
}