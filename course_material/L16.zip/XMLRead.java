import org.w3c.dom.*;
import javax.xml.parsers.*;
import java.io.*;
import java.util.*;
import org.xml.sax.*;

public class XMLRead {
	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException{
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		Document doc = builder.parse("test.xml");
		Element root = doc.getDocumentElement();
		System.out.println(root.getTagName());
		NodeList children = root.getChildNodes();
		for (int i = 0; i < children.getLength(); i++) {
			System.out.println(children.item(i));
		}
	}
}