import javax.swing.*;
import java.awt.event.*;
import java.awt.EventQueue;
import java.io.*;
import java.util.prefs.*;
import java.util.*;

public class ImageViewerPref {
	public static void main(String[] args) {
		EventQueue.invokeLater( () -> {
				var frame = new ImageViewerFrame();
				frame.setTitle("ImageViewer");
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setVisible(true);
		});
	}
}

class ImageViewerFrame extends JFrame{
	public ImageViewerFrame() {
		Preferences root  = Preferences.userRoot();
		// Preferences root = Preferences.systemRoot();
		Preferences node = root.node("/edu/rpi/csci4963");
		// Preferences node = Preferences.userNodeForPackage(this.getClass());
		
		int left = node.getInt("left", 0);
		int top = node.getInt("top", 0);
		int width = node.getInt("width", DEFAULT_WIDTH);
		int height = node.getInt("height", DEFAULT_HEIGHT);
		setBounds(left, top, width, height);		
		
		addWindowListener(new WindowAdapter() {
				@Override
				public void windowClosing(WindowEvent event) {
					node.putInt("left", getX());
					node.putInt("top", getY());
					node.putInt("width", getWidth());
					node.putInt("height", getHeight());
					
					try (FileOutputStream out = new FileOutputStream("prefs.xml")) {
						node.exportSubtree(out);
					}
					catch (Exception e) {}

					System.exit(0);
				}
		});
		
		add(label);
		
		var chooser = new JFileChooser();
		chooser.setCurrentDirectory(new File("."));
		
		var menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		var menu = new JMenu("File");
		menuBar.add(menu);
		
		var openItem = new JMenuItem("Open");
		menu.add(openItem);
		
		openItem.addActionListener( event -> {
				int result = chooser.showOpenDialog(null);
				if (result == JFileChooser.APPROVE_OPTION) {
					image = chooser.getSelectedFile().getPath();
					label.setIcon(new ImageIcon(image));
				}
		});
		
		var exitItem = new JMenuItem("Exit");
		menu.add(exitItem);
		exitItem.addActionListener(event -> {
				System.exit(0);
		});
	}
	
	private static final int DEFAULT_WIDTH = 300;
	private static final int DEFAULT_HEIGHT = 200;
	private File propertiesFile;
	private Properties settings; 
	private String image;
	private JLabel label = new JLabel();
}