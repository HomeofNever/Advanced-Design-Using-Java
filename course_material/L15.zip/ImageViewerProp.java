import javax.swing.*;
import java.awt.event.*;
import java.awt.EventQueue;
import java.io.*;
import java.util.*;

public class ImageViewerProp {
	public static void main(String[] args) {
		EventQueue.invokeLater( () -> {
				var frame = new ImageViewerFrame();
				frame.setTitle("ImageViewer");
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setVisible(true);
		});
	}
}

class ImageViewerFrame extends JFrame{
	public ImageViewerFrame() {
		String userDir = System.getProperty("user.home");
		System.out.println(userDir);
		
		Properties defaultSettings = new Properties();
		defaultSettings.setProperty("left", "100");
		defaultSettings.setProperty("top", "100");
		defaultSettings.setProperty("width", "" + DEFAULT_WIDTH);
		defaultSettings.setProperty("height", "" + DEFAULT_HEIGHT);
		settings = new Properties(defaultSettings);

		//settings = new Properties();
		propertiesFile = new File("ImageViewer.properties");
		/*File propertiesDir = new File(userDir, ".appjava");
        if (!propertiesDir.exists()) propertiesDir.mkdir();
        propertiesFile = new File(propertiesDir, "program.properties");*/
		
		if (propertiesFile.exists()) {
			try (InputStream in = new FileInputStream(propertiesFile))
			{
				settings.load(in);
			}
			catch (IOException e) {
				e.printStackTrace();
			}
		}
		int left = Integer.parseInt(settings.getProperty("left"));
		//int left = Integer.parseInt(settings.getProperty("left", "0"));
		int top = Integer.parseInt(settings.getProperty("top"));
		int width = Integer.parseInt(settings.getProperty("width"));
		int height = Integer.parseInt(settings.getProperty("height"));
		image = settings.getProperty("mainwindow.icon");
		viewerImage = settings.getProperty("mainwindow.viewer.icon");
		setBounds(left, top, width, height);
		setIconImage(new ImageIcon(image).getImage());
		label.setIcon(new ImageIcon(viewerImage));
		
		addWindowListener(new WindowAdapter() {
				@Override
				public void windowClosing(WindowEvent event) {
					settings.setProperty("left", "" + (int)getX());
					settings.setProperty("top", "" + (int)getY());
					settings.setProperty("width", "" + (int)getWidth());
					settings.setProperty("height", "" + (int)getHeight());
					if (image != null) {
						settings.setProperty("mainwindow.icon", image);
					}
					if (viewerImage != null) {
						settings.setProperty("mainwindow.viewer.icon", viewerImage);
					}
					
					try (var out = new FileOutputStream(propertiesFile)) {
						settings.store(out, "Program Properties");
						System.out.println("File written");
					}
					catch (IOException ex) {
						ex.printStackTrace();
					}
					System.exit(0);
				}
		});
		
		add(label);
		
		JFileChooser chooser = new JFileChooser();
		chooser.setCurrentDirectory(new File("."));
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu menu = new JMenu("File");
		menuBar.add(menu);
		
		JMenuItem openItem = new JMenuItem("Open");
		menu.add(openItem);
		
		openItem.addActionListener( event -> {
				int result = chooser.showOpenDialog(null);
				if (result == JFileChooser.APPROVE_OPTION) {
					viewerImage = chooser.getSelectedFile().getPath();
					label.setIcon(new ImageIcon(viewerImage));
					image = viewerImage;
					setIconImage(new ImageIcon(image).getImage());
				}
		});
		
		JMenuItem exitItem = new JMenuItem("Exit");
		menu.add(exitItem);
		exitItem.addActionListener(event -> {
				System.exit(0);
		});

	}
	
	private static final int DEFAULT_WIDTH = 300;
	private static final int DEFAULT_HEIGHT = 200;
	private File propertiesFile;
	private Properties settings; 
	private String image, viewerImage;
	private JLabel label = new JLabel();
}