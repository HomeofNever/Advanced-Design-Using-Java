package mypackage;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Hello
 */
public class Hello extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
  public Hello() {
      super();
      // TODO Auto-generated constructor stub
  }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

    response.getWriter().append("<html><head><meta charset=\"UTF-8\" /><title>Sample Application JSP Page</title></head>" +
        "<body><div style=\"float: left; padding: 10px;\"><img src=\"images/tomcat.gif\" alt=\"\" /></div>" +
        "<h1>Sample Application JSP Page</h1>This is the output of a JSP page that is part of " +
        "the Hello, World application." +  new String("Hello!") +
        "</body></html>");

	}
}

















