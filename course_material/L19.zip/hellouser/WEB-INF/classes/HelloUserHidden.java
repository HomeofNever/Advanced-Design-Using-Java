import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Hello
 */
@WebServlet("/HelloHidden")
public class HelloUserHidden extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
  public HelloUserHidden() {
      super();
      // TODO Auto-generated constructor stub
  }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		if (request.getParameter("page") != null) {
      int page = 1;
      try {
        page = Integer.parseInt(request.getParameter("page"));

        if (page == 1) {
          response.getWriter().append("<html><title>Greeting Web App with the Wizard</title><body>" +
              "I have seen you before!<br/>" +
              "<h1>Hello, " + request.getParameter("name") + 
              "</h1>" + "<form method=\"POST\">Enter your age:<br/><input name=\"age\" type=\"text\">" +
              "<input name=\"page\" type=\"hidden\" value=\"2\">" +
              "<input name=\"name\" type=\"hidden\" value=\"" + request.getParameter("name") + "\">" + 
              "<br/><input type=\"submit\" value=\"Next\"></form>" + 
              "</body></html>");
        }
        else if (page == 2) {
          response.getWriter().append("<html><title>Greeting Web App with the Wizard</title><body>" +
              "I have seen you before!<br/>" +
              "<h1>Hello, " + request.getParameter("name") + ". You are " + request.getParameter("age") + " years old." +
              "</h1></body></html>");
        }
        return;
      }
      catch (Exception e) { }
    }

    response.getWriter().append("<html><title>Greeting Web App with the Wizard</title><body>" +
        "<form method=\"POST\">Enter your name:<br/><input name=\"name\" type=\"text\">" +
        "<input name=\"page\" type=\"hidden\" value=\"1\"><br/><input type=\"submit\" value=\"Next\"></form>" +
        "</body></html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
