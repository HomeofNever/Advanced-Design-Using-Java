import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class Details extends HttpServlet {
  public void doGet(HttpServletRequest request, HttpServletResponse response){
  PrintWriter pwriter = null;
  try{
      response.setContentType("text/html");
      pwriter = response.getWriter();
      HttpSession session=request.getSession(false);
      if (request.getParameter("btn2") != null){
        session.invalidate();
        response.sendRedirect("index.html");
      }
      String myName=(String)session.getAttribute("uname");
      String myPass=(String)session.getAttribute("upass");
      pwriter.print("Name: "+myName+" Pass: "+myPass);
      pwriter.print("<form><input type=\"submit\" name=\"btn1\" value=\"Press me!\"/>" +
        "<input type=\"submit\" name=\"btn2\" value=\"Try me!\"/></form>");
      pwriter.close();
  }catch(Exception exp){
      System.out.println(exp);
      pwriter.print(exp);
   }
  }
}