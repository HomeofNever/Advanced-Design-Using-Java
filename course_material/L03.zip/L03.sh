#!/bin/bash
# Don't forget to "chmod ugo+x ./L03.sh"
# bash scripting tutorial: https://www.tutorialkart.com/bash-shell-scripting/
# This is a comment

javac ./lec03/L03.java
javadoc -author -version -d doc ./lec03/L03.java
java lec03.L03 $1 $2
for i in `seq 1 3`
do
    for j in `seq 5 6`
    do
        java lec03.L03 $i $j
    done
done

# javac -encoding UTF-8 ./lec03/L03.java
# javadoc -author -version -d doc ./lec03/L03.java
# java -Dfile.encoding=UTF-8 lec03.L03 $1 $2
# for i in `seq 1 3`
# do
    # for j in `seq 5 6`
    # do
        # java -Dfile.encoding=UTF-8 lec03.L03 $i $j
    # done
# done

