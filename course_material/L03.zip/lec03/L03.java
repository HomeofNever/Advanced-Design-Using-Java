package lec03;

import java.util.*;
import java.io.*;
import javax.swing.*;

/*   */

/**
* Demo code for Lecture 3
* @author Konstantin Kuzmin
* @version <b>1.0</b> rev. 0
*/
public class L03
{
	/**
	* Contains the welcome message printed by main()
	*/
	private static final String greeting = "Welcome to Application Programming Using Java!";
	
   /**
   * main() method
   * @param args - command line arguments
   * @exception FileNotFoundException If file is not found
   * @exception IOException If some I/O issue occurred
   */
   public static void main\u0028String[] args) throws FileNotFoundException, IOException
   {
   	  System.out.println(greeting);

      for (int i = 0; i < greeting.length(); i++)
        System.out.print("=");
      System.out.println();
      int arg1 = Integer.valueOf(args[0]);
      int arg2 = Integer.valueOf(args[1]);
      System.out.printf("Sum of %d and %d is %d.\n", arg1, arg2, arg1 + arg2);
      
      byte b1 = 10; // -128 .. 127
      byte b2 = 45 + 45;
      System.out.println(b2);
      byte b3 = (byte)(b1 + b2);
      System.out.println(b3);

      short s; // -32768 .. 32767
      s = 32767;
      //s = s + 1; //s += 1; s++;
      s++;
      s += 1;
      System.out.println(s);
      int i = 100;
      long l = 100_000L * 1000 * 1000 * 365 * 1000; //100l
      int i1 = 0xCAFE;
      int i2 = 0b0001_0000;
      
      System.out.printf("%H\n", i1);
      System.out.println(Integer.MAX_VALUE);
      
      float f1 = 3.512345678912F; // float: 10-38 .. 10+38
      double d1 = 3.5e-45;  // 10-308 .. 10+308
      d1 = 3.5e-208;
      f1 = 3.5e-25f;
      System.out.printf("%e %e %e\n", f1, f1 * f1, (double)f1 * f1);
      System.out.printf("%e %e\n", d1, d1 * d1);
      d1 = 1e308;
      System.out.println(d1 * d1);
      d1 = 0.0;
      int i3 = 0;
      System.out.println(i3 / i3);
      System.out.println(5.0 / i3);
   }
}
