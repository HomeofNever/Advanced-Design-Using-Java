package edu.rpi.cs.xieo.csci4960.contacts;

import java.io.*;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Main {

    public static void main(String[] args) {
        // Create book of contacts
        Address rpi = new Address("110 Eighth Street", "Troy, NY", "USA", 12180);
        Address oracle = new Address("500 Oracle Pkwy", "Redwood City, CA", "USA", 94065);
        Person a = new Person("alice", rpi);
        Person b = new Person("bob", rpi);
        Person e = new Person("eve", oracle);

        a.addKnowledgeOf(b);
        b.addKnowledgeOf(a);
        e.addKnowledgeOf(a);
        e.addKnowledgeOf(b);

        // Most list *implementations* are serializable
        List<Person> contacts = Arrays.asList(a, b, e);
        System.out.println("Before Saving:");
        printContacts(contacts);

        String file = "tmp.txt";
        try (ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(file))) {
            os.writeObject(contacts);
        } catch (IOException io) {
            io.printStackTrace();
        }

        try (ObjectInputStream is = new ObjectInputStream(new FileInputStream(file))) {
            // One drawback - we need to ensure that the type really is what it is
            List<Person> saved_contacts = (List<Person>) is.readObject();
            System.out.println("\nAfter Loading:");
            printContacts(saved_contacts);
        } catch (IOException io) {
            io.printStackTrace();
        } catch (ClassNotFoundException cnfe) {
            System.err.println("Object was not of correct type!");
        }
    }

    public static void printContacts(List<Person> contacts) {
        System.out.println(contacts.stream().map(Person::toString).collect(Collectors.joining("\n")));
    }
}
