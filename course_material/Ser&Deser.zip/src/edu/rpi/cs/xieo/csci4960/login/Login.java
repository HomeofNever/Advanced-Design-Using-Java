package edu.rpi.cs.xieo.csci4960.login;

import java.io.Serializable;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class Login implements Serializable {
    public final String username;
    private final String password_hash;
    private final transient String password;

    public Login(String username, String password) {
        this.username = username;
        this.password = password;

        String result = "";
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] digest = md.digest(password.getBytes());
            BigInteger digest_num = new BigInteger(digest);
            result = digest_num.toString(16);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        this.password_hash = result;
    }

    @Override
    public String toString() {
        return username + ": " + password + " - " + password_hash;
    }
}
