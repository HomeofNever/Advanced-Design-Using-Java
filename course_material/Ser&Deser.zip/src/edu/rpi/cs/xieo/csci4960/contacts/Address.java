package edu.rpi.cs.xieo.csci4960.contacts;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class Address implements Serializable {
    public String street;
    public String city;
    public String country;
    public int zip_code;

    public Address(String street, String city, String country, int zip_code) {
        this.street = street;
        this.city = city;
        this.country = country;
        this.zip_code = zip_code;
    }

    /**
     * Customize the serialization, although this isn't really much different.
     */
    private void writeObject(ObjectOutputStream os) throws IOException {
        // Essentially equivalent to
        // os.defaultWriteObject();

        os.writeObject(street);
        os.writeObject(city);
        os.writeObject(country);
        os.writeInt(zip_code);
    }

    /**
     * Note that if we decide to customize deserialization, we need the fields to not be final.
     */
    private void readObject(ObjectInputStream is) throws IOException, ClassNotFoundException {
        // Essentially equivalent to
        // os.defaultReadObject()

        this.street = (String) is.readObject();
        this.city = (String) is.readObject();
        this.country = (String) is.readObject();
        this.zip_code = is.readInt();
    }

    @Override
    public String toString() {
        return street + ", " + city + ", " + country + ". " + zip_code;
    }
}
