package edu.rpi.cs.xieo.csci4960.banking;

import java.io.Serializable;

public abstract class BankMessage implements Serializable {
    private static final long serialVersionUID = 1;
    public abstract void visit(Bank bank);
}
