package edu.rpi.cs.xieo.csci4960.login;

import java.io.*;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Main {

    public static void main(String[] args) {
        Login a = new Login("user", "bad_password");
        Login b = new Login("owen", "correcthorsebatterystaple");

        List<Login> logins = Arrays.asList(a, b);

        System.out.println("Before Saving:");
        System.out.println(logins.stream().map(Login::toString).collect(Collectors.joining("\n")));

        String file = "logins.txt";
        try (ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(file))) {
            os.writeObject(logins);
        } catch (IOException io) {
            io.printStackTrace();
        }

        try (ObjectInputStream is = new ObjectInputStream(new FileInputStream(file))) {
            List<Login> saved_logins = (List<Login>) is.readObject();
            System.out.println("\nAfter Loading:");
            System.out.println(saved_logins.stream().map(Login::toString).collect(Collectors.joining("\n")));
        } catch (IOException io) {
            io.printStackTrace();
        } catch (ClassNotFoundException cnfe) {
            System.err.println("Object was not of correct type!");
        }
    }
}
