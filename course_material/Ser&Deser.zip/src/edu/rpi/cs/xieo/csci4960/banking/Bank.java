package edu.rpi.cs.xieo.csci4960.banking;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Bank {
    int money = 100;

    public static void main(String[] args) {
        Bank bank = new Bank();

        try (ServerSocket serverSocket = new ServerSocket(5000);
             Socket socket = serverSocket.accept();
             ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
             ObjectInputStream in = new ObjectInputStream(socket.getInputStream());) {
            System.out.println("Server is listening...");
            while (socket.isConnected()) {
                BankMessage msg = (BankMessage) in.readObject();
                msg.visit(bank);
                System.out.println(msg);
                out.writeObject(new BalanceUpdate(bank.money));
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void deposit() {
        this.money += 100;
    }

    public void withdraw() {
        this.money -= 100;
    }
}
