package edu.rpi.cs.xieo.csci4960.banking;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.List;

public class Client {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Client");
            JPanel panel = new JPanel();
            JLabel money = new JLabel("$100");
            Font font = new Font("Arial", Font.PLAIN, 40);
            money.setFont(font);
            JButton withdraw = new JButton("Withdraw $100");
            withdraw.setFont(font);
            JButton deposit = new JButton("Deposit $100");
            deposit.setFont(font);

            ClientWorker network = new ClientWorker(money);

            withdraw.addActionListener(e -> {
                try {
                    network.send(new Withdraw());
                } catch (IOException ioException) {
                    ioException.printStackTrace();
                }
            });

            deposit.addActionListener(e -> {
                try {
                    network.send(new Deposit());
                } catch (IOException ioException) {
                    ioException.printStackTrace();
                }
            });

            panel.add(money);
            panel.add(withdraw);
            panel.add(deposit);

            frame.add(panel);
            frame.pack();
            network.execute();
            frame.setVisible(true);
        });
    }

    private static class ClientWorker extends SwingWorker<Void, BalanceUpdate> {

        public final JLabel money;
        public ObjectOutputStream out = null;

        public ClientWorker(JLabel money) {
            this.money = money;
        }

        @Override
        protected Void doInBackground() {
            try (Socket socket = new Socket("localhost", 5000);
                 ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
                 ObjectInputStream in = new ObjectInputStream(socket.getInputStream());) {
                this.out = out;
                while (socket.isConnected()) {
                    try {
                        BalanceUpdate msg = (BalanceUpdate) in.readObject();
                        this.publish(msg);
                    } catch (ClassCastException | ClassNotFoundException ce) {
                        ce.printStackTrace();
                    }
                }
            } catch (IOException e) {
                System.err.println("Network error!");
            } finally {
                this.out = null;
            }

            return null;
        }

        public void send(BankMessage msg) throws IOException {
            this.out.writeObject(msg);
        }

        @Override
        public void process(List<BalanceUpdate> chunks) {
            BalanceUpdate last = chunks.get(chunks.size() - 1);
            this.money.setText("$" + last.balance);
        }
    }
}
