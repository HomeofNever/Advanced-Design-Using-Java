package edu.rpi.cs.xieo.csci4960.banking;

import java.io.Serializable;

public class BalanceUpdate implements Serializable {
    private static final long serialVersionUID = 1;
    public final int balance;

    public BalanceUpdate(int balance) {
        this.balance = balance;
    }
}
