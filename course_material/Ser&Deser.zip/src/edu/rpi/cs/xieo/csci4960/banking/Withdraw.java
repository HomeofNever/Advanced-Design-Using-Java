package edu.rpi.cs.xieo.csci4960.banking;

public class Withdraw extends BankMessage {
    @Override
    public void visit(Bank bank) {
        bank.withdraw();
    }
}
