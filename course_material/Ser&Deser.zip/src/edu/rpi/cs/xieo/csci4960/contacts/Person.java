package edu.rpi.cs.xieo.csci4960.contacts;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.stream.Collectors;

public class Person implements Serializable {
    public final String name;
    public final Address address;
    private final ArrayList<Person> knows = new ArrayList<>();

    public Person(String name, Address address) {
        this.name = name;
        this.address = address;
    }

    public void addKnowledgeOf(Person member) {
        this.knows.add(member);
    }

    /**
     * Avoids infinite recursion.
     */
    public String header() {
        return name + ": " + address;
    }

    @Override
    public String toString() {
        String header =  name + ": " + address + "\n";
        String family = this.knows
                .stream().map(p -> "\t" + p.header())
                .collect(Collectors.joining("\n"));
        return header + family;
    }
}
