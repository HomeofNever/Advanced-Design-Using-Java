
USE advjava;

SELECT * FROM advjava.airports
WHERE airport = 'XYZ international airport';

USE advjava;
DELETE FROM airports
WHERE id = 456665;


SELECT A1.city, A1.latitude, A1.longitude, A2.city, A2.latitude, A2.longitude
FROM advjava.airports AS A1
CROSS JOIN advjava.airports AS A2;

SELECT A1.city, A1.latitude, A1.longitude, A2.city, A2.latitude, A2.longitude,
( 3959 * acos( cos( radians(A1.latitude) ) * cos( radians( A2.latitude ) ) 
* cos( radians(A2.longitude) - radians(A1.longitude) ) + sin( radians(A1.latitude) ) * sin(radians(A2.latitude)) ) ) AS distance
FROM advjava.airports AS A1
CROSS JOIN advjava.airports AS A2;


SELECT A1.airport, A1.city, A1.country, A2.airport, A2.city, A2.country  
FROM advjava.airports AS A1
CROSS JOIN advjava.airports AS A2;

INSERT INTO routes
VALUES ("My Airline", 22000, 'Beijing Capital International Airport',
2677777, 'Beijing Nanyuan Airport', 9281282, "None", 1, "B747");

SELECT *
FROM routes
WHERE airline="My Airline";

-- Unsafe

DELETE FROM routes
WHERE airline="My Airline";

-- Safe

DELETE FROM routes
WHERE airline_id=22000 and src_airport_id = 2677777 and dst_airport_id = 9281282;




CALL `advjava`.`airports_by_country`('China');
