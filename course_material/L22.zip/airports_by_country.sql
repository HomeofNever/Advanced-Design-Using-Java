USE advjava;

DELIMITER //

DROP PROCEDURE `airports_by_country`//

CREATE PROCEDURE `airports_by_country`(IN s_country VARCHAR(255))
BEGIN
SELECT airport, iata, city, country, latitude, longitude
FROM advjava.airports
WHERE country = s_country;
END //
DELIMITER ;