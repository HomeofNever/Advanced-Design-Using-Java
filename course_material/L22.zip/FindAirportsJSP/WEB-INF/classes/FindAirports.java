package appjava;

import java.util.prefs.*;
import java.sql.*;
import java.util.*;

public class FindAirports {
  public FindAirports() {
    Preferences root  = Preferences.userRoot();
    Preferences node = Preferences.userNodeForPackage(this.getClass());
    // Edit the connection string in your Preferences API storage to include MySQL username and password
    this.connString = node.get("MySQLConnection", "jdbc:mysql://localhost:3306/advjava?useSSL=false");
    System.out.println(connString);
    node.put("MySQLConnection", connString);
  }
  
  public ArrayList<ArrayList<String>> getAirportsByCityCountry(String city, String country) {
    ArrayList<ArrayList<String>> result = new ArrayList<ArrayList<String>>();
    ArrayList<String> row;
    String query = "SELECT airport, city, country, latitude, longitude " + 
            "FROM advjava.airports WHERE country = ? AND city = ?";
    Connection con = openConnection();
    try (PreparedStatement stat = con.prepareStatement(query)) {
      stat.setString(1, country);
      stat.setString(2, city);
      try (ResultSet rs = stat.executeQuery()) {
        while (rs.next()) {
          row = new ArrayList<String>();
          result.add(row);
          row.add(rs.getString(1));
          row.add(rs.getString("city"));
          row.add(rs.getString(3));
          row.add(String.format("%.2f", rs.getDouble(4)));
          row.add(String.format("%.2f", rs.getDouble(5)));
        }
      }
    }
    catch (SQLException ex) {
      for (Throwable t : ex)
        System.out.println(t.getMessage());
      System.out.println("Opening connection failed!");
    }
    return result;
  }
  
  private Connection openConnection() {
    Connection con = null;
    try {
      con = DriverManager.getConnection(connString);
    }
    catch (SQLException ex) {
      for (Throwable t : ex)
        System.out.println(t.getMessage());
      System.out.println("Opening connection failed!");
    }
    return con;
  }

  private void closeConnection(Connection con) {
    if (con != null) {
      try {
        con.close();
      }
      catch (SQLException ex) {
        for (Throwable t : ex)
          System.out.println(t.getMessage());
        System.out.println("Closing connection failed!");
      }
    }
  }

  private String connString;
}
