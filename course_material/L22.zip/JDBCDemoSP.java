import java.sql.*;
import java.util.*;
import java.lang.reflect.*;
import java.awt.Desktop;
import java.net.URI;
import java.util.prefs.*;

public class JDBCDemoSP {
	public static void main(String[] args) {
    /*try {
			Class.forName("com.mysql.cj.jdbc.Driver").getDeclaredConstructor().newInstance();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/

		Preferences root  = Preferences.userRoot();
		Preferences node = Preferences.userNodeForPackage(JDBCDemoINS_DEL.class);
		// Edit the preference in the OS store (Windows Registry, Linux configuration file, etc.
		//   to include MySQL username and password in the form:
		//   jdbc:mysql://username:password@localhost:3306/advjava?useSSL=false
		String url = node.get("MySQLConnection", "jdbc:mysql://localhost:3306/advjava?useSSL=false");
		try (Connection con = DriverManager.getConnection(url))
		{
			String country;
			Scanner in = new Scanner(System.in);
			System.out.print("Enter country name: ");
			country = in.nextLine();
			CallableStatement stat = con.prepareCall("{call `advjava`.`airports_by_country`(?)}");

			{
				stat.setString(1, country);
				try (ResultSet rs = stat.executeQuery()) {
					while (rs.next()) {
						System.out.printf("Airport: %s, City: %s, Country: %s", rs.getString(1),
							rs.getString("city"), rs.getString("country"));
						System.out.printf(" Coordinates: (%.4f %.4f)\n", 
							rs.getDouble("latitude"), rs.getDouble("longitude"));
						// Desktop d = Desktop.getDesktop();
						// try {
						// URI address = new URI("http://www.google.com/maps/@?api=1&map_action=map&center="+
							// rs.getDouble(4) + "," + rs.getDouble(5) + "&basemap=satellite");
						// d.browse(address);
						// }
						// catch (Exception e) {}
						
					}
				}
			}
		}
		catch (SQLException ex) {
			for (Throwable t : ex)
				System.out.println(t.getMessage());
			System.out.println("Connection unsuccessful!");
		}
		node.put("MySQLConnection", url);
	}
}