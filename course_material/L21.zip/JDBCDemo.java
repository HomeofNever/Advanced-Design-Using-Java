import java.sql.*;
import java.util.*;
import java.net.*;
import java.awt.Desktop;

public class JDBCDemo {
	public static void main(String... args) {
		/*try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
		}
		catch (Exception ex) {
			System.out.println(ex.getMessage());
		}*/
		Connection con = null;
		String url = "jdbc:mysql://localhost:3306/advjava?useSSL=false";
		try {
			con = DriverManager.getConnection(url, "***", "***");
			String city, country;
			Scanner in = new Scanner(System.in);
			System.out.print("Enter country name: ");
			country = in.nextLine();
			System.out.print("Enter city name: ");
			city = in.nextLine();
			
			String query = "SELECT airport, city, country, latitude, longitude" +
				" FROM advjava.airports " +
				" WHERE country=? AND city=?;";
			try {
				PreparedStatement stat = con.prepareStatement(query);
				stat.setString(1, country);
				stat.setString(2, city);
				ResultSet rs = stat.executeQuery();
				while(rs.next()) {
					System.out.printf("Airport %s, City %s, Country: %s", rs.getString(1), 
						rs.getString("city"), rs.getString(3));
					System.out.printf("Latitude: %.4f, Longitude: %.4f%n", 
						rs.getDouble(4), rs.getDouble(5));
					
					Desktop d = Desktop.getDesktop();
					URI address = new URI("http://www.google.com/maps/@?api=1&map_action=map&center="+
						rs.getDouble(4) + "," + rs.getDouble(5) + "&basemap=satellite");
					d.browse(address);
				}
			}
			catch (Exception ex) {
				System.out.println(ex.getMessage());
			}
		}
		catch (SQLException ex) {
			for (Throwable t : ex) {
				System.out.println(t.getMessage());
			}
			System.out.println("Opening connection was unsuccessful!");
		}
		finally {
			if (con != null) {
				try {
					con.close();
				}
				catch (SQLException ex) {
					for (Throwable t : ex) {
						System.out.println(t.getMessage());
					}
					System.out.println("Closing connection was unsuccessful!");
				}
			}
		}
	}
}