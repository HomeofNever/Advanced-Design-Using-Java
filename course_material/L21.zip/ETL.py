f = open("Export.csv")
for line in f:
    record = [field.strip() for field in line.split(',')]
    record.append("0")
    print(record)