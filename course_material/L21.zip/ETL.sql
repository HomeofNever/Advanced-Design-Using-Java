DROP DATABASE openflight;
CREATE SCHEMA openflight;
USE openflight;

FLUSH privileges;

SHOW GLOBAL VARIABLES LIKE 'local_infile';
SET GLOBAL local_infile = 'ON';
SHOW GLOBAL VARIABLES LIKE 'local_infile';

USE openflight;

CREATE TABLE `airlines` (
  `id` INT NOT NULL,
  `name` VARCHAR(255) DEFAULT NULL,
  `alt_name` VARCHAR(255) DEFAULT NULL,
  `iata` VARCHAR(2) DEFAULT NULL,
  `icao` VARCHAR(3) DEFAULT NULL,
  `callsign` VARCHAR(255) DEFAULT NULL,
  `country` VARCHAR(255) DEFAULT NULL,
  `active` BOOLEAN DEFAULT NULL
);

SET GLOBAL local_infile = 'ON';

LOAD DATA INFILE 'c:\\ProgramData\\MySQL\\MySQL Server 8.0\\Uploads\\airlines.dat' INTO TABLE airlines
FIELDS TERMINATED BY ',' ENCLOSED BY '\"'
LINES TERMINATED BY '\n' (id, name, alt_name, iata, icao, callsign, country, @var3)
SET active = (@var3 = 'Y');
SHOW WARNINGS;
SELECT * FROM airlines;


-- Alternative: mysqlimport --local --verbose --delete --columns=id,name,alt_name,iata,icao,callsign,country,active --fields-terminated-by=\, --fields-optionally-enclosed-by=\" --lines-terminated-by=\n --user=Cony -p openflight "c:\ProgramData\MySQL\MySQL Server 8.0\Uploads\airlines.csv"