import java.sql.*;
import java.util.*;
import java.lang.reflect.*;
import java.awt.Desktop;
import java.net.URI;
import java.util.prefs.*;

public class JDBCDemoINS_DEL {
	public static void main(String[] args) {
    /*try {
			Class.forName("com.mysql.cj.jdbc.Driver").getDeclaredConstructor().newInstance();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		Preferences root  = Preferences.userRoot();
		Preferences node = Preferences.userNodeForPackage(JDBCDemoINS_DEL.class);
		// Edit the preference in the OS store (Windows Registry, Linux configuration file, etc.
		//   to include MySQL username and password in the form:
		//   jdbc:mysql://username:password@localhost:3306/advjava?useSSL=false
		String url = node.get("MySQLConnection", "jdbc:mysql://localhost:3306/advjava?useSSL=false");
		try (Connection con = DriverManager.getConnection(url))
		{
			String city, country;
			String query = "INSERT INTO airports (id, airport, city, country)" + 
						  "VALUES (?,?,?,?)";
			try (PreparedStatement stat = con.prepareStatement(query)) {
				stat.setString(1, "456665");
				stat.setString(2, "XYZ international airport");
				stat.setString(3, "XYZ city");
				stat.setString(4, "XYZ country");
				int rows = stat.executeUpdate();
				System.out.println("Rows inserted: " + rows);	
			}
			query = "DELETE FROM airports " + 
					"WHERE id = 456665;";
			try (PreparedStatement stat = con.prepareStatement(query)) {
				int rows = stat.executeUpdate();
				System.out.println("Rows deleted: " + rows);
			}
		}
		catch (SQLException ex) {
			for (Throwable t : ex)
				System.out.println(t.getMessage());
			System.out.println("Connection unsuccessful!");
		}
		node.put("MySQLConnection", url);
	}
}