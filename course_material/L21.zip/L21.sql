SELECT *
FROM advjava.airlines
WHERE country = 'China';

SELECT airport, iata, city, country, latitude, longitude
FROM advjava.airports
WHERE country = 'China' AND city = 'Beijing';

SELECT COUNT(*)
FROM advjava.airports;

-- Query which returns 0 rows

SELECT airport, iata, city, country, latitude, longitude
FROM advjava.airports
WHERE id = 99999;

-- All routes to or from St.Petersburg

SELECT SA.city AS 'From', DA.city AS 'To'
FROM advjava.routes AS R
INNER JOIN advjava.airports AS SA ON R.src_airport_id = SA.id
INNER JOIN advjava.airports AS DA ON R.dst_airport_id = DA.id
WHERE SA.iata = 'LED' OR DA.iata = 'LED'
ORDER BY SA.city ASC




