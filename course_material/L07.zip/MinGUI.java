import java.awt.*;
import javax.swing.*; 
import java.io.*;

public class MinGUI {
	public static void main(String[] args) {
		System.out.println("Before messagebox is shown");
		JOptionPane msg = new JOptionPane();
		String str = msg.showInputDialog(null, "Please Enter the value");
		int val = Integer.parseInt(str);
		System.out.printf("You entered %d which is 0x%x\n", val, val);
		JFileChooser chooser = new JFileChooser();
		int result = chooser.showOpenDialog(null);
		String path = chooser.getSelectedFile().getAbsolutePath();
		String filename = chooser.getSelectedFile().getName();
		System.out.printf("The following file was selected: %s\n", path);
	}
}