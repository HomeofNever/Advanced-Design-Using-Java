import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * A frame with a button panel.
 */
public class ButtonFrame extends JFrame
{
   private JPanel buttonPanel;
   private static final int DEFAULT_WIDTH = 300;
   private static final int DEFAULT_HEIGHT = 200;

   public ButtonFrame()
   {
      setSize(DEFAULT_WIDTH, DEFAULT_HEIGHT);

      // create buttons
      var yellowButton = new JButton("Yellow");
      var blueButton = new JButton("Blue");
      var redButton = new JButton("Red");
      var blackButton = new JButton("Black");

      buttonPanel = new JPanel();
      buttonPanel.setLayout(new BorderLayout());

      // add buttons to panel
      buttonPanel.add(yellowButton, BorderLayout.SOUTH);
      buttonPanel.add(blueButton, BorderLayout.WEST);
      var eastPanel = new JPanel();
      eastPanel.setLayout(new GridLayout(2, 1));
      eastPanel.add(redButton);
      eastPanel.add(blackButton);
      buttonPanel.add(eastPanel, BorderLayout.EAST);

      // add panel to frame
      add(buttonPanel);

      // create button actions
      var yellowAction = new ColorAction(Color.YELLOW);
      var blueAction = new ColorAction(Color.BLUE);
      var redAction = new ColorAction(Color.RED);
      var blackAction = new ColorAction(Color.BLACK);

      // associate actions with buttons
      yellowButton.addActionListener(yellowAction);
      blueButton.addActionListener(blueAction);
      redButton.addActionListener(redAction);
      blackButton.addActionListener(blackAction);
   }

   /**
    * An action listener that sets the panel's background color.
    */
   private class ColorAction implements ActionListener
   {
      private Color backgroundColor;

      public ColorAction(Color c)
      {
         backgroundColor = c;
      }

      public void actionPerformed(ActionEvent event)
      {
         buttonPanel.setBackground(backgroundColor);
      }
   }
}
