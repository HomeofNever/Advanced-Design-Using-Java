import java.util.*;

/**
* Demo code for Lecture 7
* @author Konstantin Kuzmin
* @version <b>1.0</b> rev. 0
*/

public class L07
{
   /**
   * main() method
   * @param args - command line arguments
   */
   public static void main(String[] args) // String... args
   {
   	   Outer outer = new Outer(42);
   	   System.out.println(outer.getY());
   	   
   	   Outer.Nested on = new Outer.Nested(100);
   	   System.out.println(outer.getNested().getY());
   	   System.out.println(on.getY());
   	   
   	   Outer.Inner oi = outer.new Inner(200);
   	   System.out.println(oi.getY());
   	   System.out.println(oi.getX());
   	   
   	   Outer.Inner.Inner2 oii2 = oi.new Inner2(3.14);
   	   System.out.println(oii2.getY());
   	   System.out.println(oii2.getZ());
   	   
   	   // Local loc = new Local("Local Class"); // Error!
   	   
   	   class Local {
   	   	   public Local(String desc) {
   	   	   	   this.desc = desc;
   	   	   }
   	   	   public String getDesc() {
   	   	   	   return this.desc;
   	   	   }
   	   	   private String desc;
   	   }
   	   
   	   System.out.println(new Object(){
   	   	   {
   	   	   	   this.desc = "Anonymous Class";
   	   	   }
   	   	   public String getDesc() {
   	   	   	   return this.desc;
   	   	   }
   	   	   private String desc;
   	   }.getDesc());
   	   
   	   Local loc = new Local("Local Class");
   	   System.out.println(loc.getDesc());

   	   Drawable dr = new Drawable() {
          void move(double dx, double dy) {
             return;
          }
   	   };
   	   
   	   System.out.println(new Shape() {
          public void resize(double f1, double f2) {
          }
   	   }.getClass());
   	   
   	   System.out.println(Drawable.convertInMm(2));
   	   Drawable shape = new Rectangle();
   	   System.out.println(shape.draw());
   }
}

class Outer {
	public Outer(int x) {
		this.x = x;
		this.nested = new Nested(55);
	}

	public int getY() {
		return nested.getY();
	}
	
	public Nested getNested() {
		return nested;
	}
	
	static class Nested {
		public Nested(int y) {
			this.y = y;
		}
		public int getY() { return y; }
		private int y;
	}
	
	class Inner {
		public class Inner2 {
			public int getY() { return Inner.this.y; }
			public double getZ() { return z; }
			public Inner2(double z) {
			   this.z = z;
		    }
			private double z = 0;
		}
		
		public Inner(int y) {
			this.y = y;
		}
		public int getY() { return y; }
		public int getX() { return Outer.this.x; }
		private int y;
	}
	
	private int x;
	private Nested nested;
	// private Local loc; // Error!
}
