import java.awt.*;
import javax.swing.*; 

public class GUI {
	public static void main(String[] args) {
		EventQueue.invokeLater(() -> 
			{
				var frame = new MyFrame();
				frame.setTitle("My Frame");
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setVisible(true);
			});
		System.out.println("App exited.");
	}
}

class MyFrame extends JFrame {
	public MyFrame() {
		add(new MyComponent());
		pack();
	}
}

class MyComponent extends JComponent
{

	public MyComponent() {
	}
		
	public void paintComponent(Graphics g) {
		g.drawString("My JComponent component", 100, 100);
	}
}