package employee;

import java.time.*;
import java.util.*;

public class Employee {
    public static final double MIN_SALARY = 1000000.0;
    public static final int STARTING_ID = 600000000;
	
    // static initialization block
    static
    {
        Random generator = new Random();
        nextId = STARTING_ID + generator.nextInt(10000000);
    }

    // object initialization block
    {
        this.id = nextId;
        nextId++;
    }
    
	public Employee() {
		/*name = "";
		salary = 100000.00;
		hireDate = null;*/
		this("N/A", MIN_SALARY, null);
	}
	public Employee(String name, double salary, LocalDate date) {
		this.name = name;
		this.salary = salary;
		this.hireDate = date;
		//this.setId();
		evaluations = new StringBuilder();
	}
	/*@Override
	public void finalize() {
	}*/
    public void setId() {
        this.id = nextId;
        nextId++;
    }
    public static int getNextId() {
        return nextId; // returns static field
    }
    public static void setNextId(int value) {
        nextId = value;
    }
    /*private static int assignId() {
        int r = nextId;
        nextId++;
        return r;
    }*/
    public String getName() {
    	return this.name;
    }
    public int getId() {
    	return this.id;
    }
    public double getSalary() {
    	return this.salary;
    }
    public LocalDate getHireDate() {
    	return this.hireDate;
    }
    public StringBuilder getEvals() {
    	return this.evaluations;
    }
    public List<Employee> getSupervisors() {
    	return this.supervisors;
    }
    /*public String getEvals() {
    	return this.evaluations.toString();
    }*/
    public void givePraise() {
        evaluations.append("\t" + LocalDate.now() + ": Above expectations!\n");
    }
    public void givePoorEval() {
        evaluations.append("\t" + LocalDate.now() + ": Poor performance!\n");
    }
    void resetEval() { // mean private? Alternatively, seal the package!
    	// evaluations = new StringBuilder(); // final!!!
        evaluations.setLength(0);
    }
    public void addSupervisors(Employee emp, Manager mgr) {
    	supervisors.add(emp);
    	supervisors.add(mgr);
    }
    public void raiseSalary(double byPercent) {
        double raise = this.salary * byPercent / 100;
        this.salary += raise;
    }
    public void setSalary(double amount) {
    	this.salary = amount;
    }
    @Override
    public String toString() {
    	    return this.getName() + " " + this.getId() + " " +
        	this.getSalary() + " hired on " + this.getHireDate() +
        	"\n" + this.getEvals();
    }
    
    
    public static void main(String[] args) { // unit test
        Employee e = new Employee("Alice", 50000, LocalDate.of(2003, 3, 31));
        //e.getNextId();
        //Employee.getNextId();
        e.raiseSalary(75);
        e.givePraise();
        //Employee.setNextId(777777);
        System.out.println(e.getName() + " " + e.getId() + " " +
        	e.getSalary() + " hired on " + e.getHireDate() + "\n" + e.getEvals());
        e = new Employee("Bob", Employee.MIN_SALARY, LocalDate.now());
        e.givePraise();
        e.givePoorEval();
        e.resetEval(); // always accessible
        e.getEvals().setLength(0);
        e.getEvals().append("\t" + LocalDate.now() +
        	": Best employee ever!\n"); // Hacking evals*/
        System.out.println(e.getName() + " " + e.getId() + " " +
        	e.getSalary() + " hired on " + e.getHireDate() + "\n" +
        	e.getEvals());
    }
    
	private final String name;
	private final StringBuilder evaluations;
    private double salary;
    private LocalDate hireDate;
    private List<Employee> supervisors = new ArrayList<Employee>();
    private int id; // nextId; // = 100;// = assignId();

    private static int nextId; // = STARTING_ID;
    
    {
        if (this.id < 0) this.id = 200;
    }
    
}
