package employee;

import java.time.*;
import java.math.*;
import java.util.*;

public class Manager extends Employee {
   private double bonus;

   public Manager(String name, double salary, int year, int month, int day)
   {
      super(name, salary, LocalDate.of(year, month, day));
      bonus = 0;
   }
 
   // Dynamic binding is used for everything but: constructors; final; static; private
   @Override
   public double getSalary()
   {
      double baseSalary = super.getSalary(); // = salary; = getSalary();  = super.getSalary();
      return baseSalary + bonus;
   }
   
   /*public double getSalary(int year)
   {
      double baseSalary = super.getSalary(); // = salary; = getSalary();  = super.getSalary();
      return year *(baseSalary + bonus);
   }*/

   /*public BigDecimal getSalary(int years) // int years
   {
      double baseSalary = super.getSalary(); // = salary; = getSalary();  = super.getSalary();
      return new BigDecimal((baseSalary + bonus) * years);
   }*/

   public void setBonus(double b)
   {
      bonus = b;
   }

   @Override
   public void raiseSalary(double byPercent) {
        double raise = this.getSalary() * 2.0 * byPercent / 100;
        this.setSalary(this.getSalary() + raise);
    }
   
   public void addSupervisors(Manager mgr, Employee emp) {
      this.getSupervisors().add(emp);
      this.getSupervisors().add(mgr);
   }
}

class CEO extends Manager {
   public CEO(String name, double salary, int year, int month, int day)
   {
      super(name, salary, year, month, day);
      privateJetModel = "Falcon 8X";
   }
	
	private String privateJetModel;
}