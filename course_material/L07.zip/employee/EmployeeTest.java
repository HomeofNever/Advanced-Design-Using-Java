package employee;

import java.time.*;
import employee.Employee;

public class EmployeeTest {
	public static void main(String[] args) {
		Employee em1 = new Employee();
		Employee em2 = new Employee("Eve", 200000.0, LocalDate.of(2019, 5, 29));
		//em1.name = "Trent ";
        em2.givePraise();
        em2.givePoorEval();
        System.out.println(em2);
        //em2.getEvals().setLength(0);
        /*em2.getEvals().setLength(0);
        em2.getEvals().append("Best employee of the month");*/
		em2.resetEval();
		System.out.println(em2);

        Manager boss = new Manager("Alice", 80000, 1987, 12, 15);
        boss.setBonus(5000);
        System.out.println(boss.getSalary());
        CEO ceo1 = new CEO("Dan", 100000, 2013, 11, 03);
        CEO ceo2 = new CEO("Carol", 1000000, 1995, 05, 19);
        
        Employee[] staff = new Employee[3];

        staff[0] = boss;
        staff[1] = new Employee("Bob", 50000, LocalDate.of(1989, 10, 1));
        staff[2] = new Employee("Eve", 40000, LocalDate.of(1990, 3, 15));
        // Employee.addSupervisors(Manager, Employee)
        // Manager.addSupervisors(Employee, Manager)
        // Actual call: addSupervisors(CEO, CEO)
        // We don't have addSupervisors(CEO, CEO)
        //boss.addSupervisors(ceo1, ceo2); 

        for (Employee e : staff)
           System.out.println("name=" + e.getName() + ",salary=" + e.getSalary() +
           	   ",supervisors:" + e.getSupervisors().toString());
	}
}
