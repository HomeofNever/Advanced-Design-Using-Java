import java.awt.Color;

public interface Drawable {
	//double x, y; // Cannot have instance fields! 
	double MM_IN_INCH = 25.4D; // a public static final constant
	
    //void draw(); // public is applied automatically
    
    default boolean draw() {
    	return false;
    }
    
    static double convertInMm(double in) {
    	return in * MM_IN_INCH;
    }
}

interface Colorable {
	Color color = Color.BLACK;
	
    void color(Color color);
    
	/*default boolean draw() {
    	return false;
    }*/
}

interface Scalable extends Drawable {
	void scale(int coeff);
}

abstract class Shape implements Drawable, Colorable {
	/*public void draw() { // what if public is skipped?
		// x = 10;
		return;
	}*/
	public void color(Color color) {
		return;
	}
	public boolean draw() {
		//return Drawable.super.draw();
		return true;
	}
	public abstract void resize(double f1, double f2);
}

class Rectangle extends Shape {
	double side = 0;
	public void resize(double f1, double f2) {
		
	}
}
