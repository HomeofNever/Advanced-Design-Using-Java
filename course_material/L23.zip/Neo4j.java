import org.neo4j.driver.*;
import org.neo4j.driver.Record;
import static org.neo4j.driver.Values.parameters;
import java.io.*;
import java.util.*;

public class Neo4j
{
	/*public enum NodeLabels implements Label {
		NODE;
	}
	public enum EdgeLabels implements RelationshipType{
		CONNECTED;
	}*/
	
	static String SERVER = "bolt://localhost";
	static String USERNAME = "***";
	static String PASSWORD = "***"; 

	public static void clearDatabase () {
		Driver driver = GraphDatabase.driver(SERVER, AuthTokens.basic(USERNAME, PASSWORD));
		Session session = driver.session();	
		session.run("MATCH(n) DETACH DELETE n;");
		session.close();
		driver.close();
	}
	
	public static void readNetFile (String fileName) {
		Driver driver = GraphDatabase.driver(SERVER, AuthTokens.basic(USERNAME, PASSWORD));
		Session session = driver.session();
		
		BufferedReader br = null;
		try{
			br = new BufferedReader(new FileReader(fileName));
			String line;
			while((line = br.readLine()) != null) {
				String[] strings = line.split(" ");
				Integer from = Integer.parseInt(strings[0]);
				Integer to = Integer.parseInt(strings[1]);
				session.run("MERGE (a:Member {id:'" + from + "'})");
				session.run("MERGE (a:Member {id:'" + to + "'})");
				session.run("MATCH (a1:Member {id:'" + from + "'}), (a2:Member {id:'" + to + "'}) MERGE (a1)-[:FRIENDS]->(a2)");
				session.run("MATCH (a1:Member {id:'" + from + "'}), (a2:Member {id:'" + to + "'}) MERGE (a2)-[:FRIENDS]->(a1)");
			}
		}
       catch (IOException ioe) 
       {
	   ioe.printStackTrace();
       } 
       finally 
       {
		   try {
			  if (br != null) {
				br.close();
			  }
			} 
			catch (IOException ioe) 
			{
				System.out.println("Error in closing the BufferedReader");
			}
		}		
		session.close();
		driver.close();			
	}
	
	public static void javaDriverDemo() {
		Driver driver = GraphDatabase.driver(SERVER, AuthTokens.basic(USERNAME, PASSWORD));
		Session session = driver.session();

		// Number of triangles
		//Result result = session.run("MATCH (a)-[]-(b)-[]-(c)-[]-(a) WHERE a.id < b.id AND b.id < c.id RETURN DISTINCT a,b,c");
		// All connections of node 1
		Result result = session.run("MATCH (a)-[]-(b) WHERE a.id = '1' RETURN DISTINCT a, b");
		int counter = 0;
		System.out.println("javaDriverDemo");
		while (result.hasNext())
		{
			counter++;
			Record record = result.next();
			System.out.println(record.get("a").get("id") + " \t" + record.get("b").get("id"));
			//System.out.println(record.get("a").get("id") + " \t" + record.get("b").get("id") + " \t" + record.get("c").get("id"));
		}
		System.out.println("Count: " + counter);
		session.close();
		driver.close();		
	}
	
	/*public static void javaNativeDemo(int nodes, double p) {
		Node node1, node2;
		int counter = 0;
		Random randomgen = new Random();
		GraphDatabaseFactory dbFactory = new GraphDatabaseFactory();
		GraphDatabaseService db = dbFactory.newEmbeddedDatabase(new File("TestNeo4jDB"));
		try (Transaction tx = db.beginTx()) {
			// Perform DB operations
			for (int i = 1; i <= nodes; i++) {
				Node node = db.createNode(NodeLabels.NODE);
				node.setProperty("id", i);
			}
			for (int i = 1; i <= nodes; i++)
				for (int j = i + 1; j <= nodes; j++) {
					if (randomgen.nextDouble() < p) {
						node1 = db.findNode(NodeLabels.NODE, "id", i);
						node2 = db.findNode(NodeLabels.NODE, "id", j);
						counter++;
						Relationship relationship = node1.createRelationshipTo(node2,EdgeLabels.CONNECTED);
						relationship = node2.createRelationshipTo(node1,EdgeLabels.CONNECTED);
					}
				}
			tx.success();
		}	
		System.out.println("" + nodes + " nodes and " + counter + " edges created");
		try (Result result = db.execute("MATCH (p) RETURN COUNT(p);")) {
			while (result.hasNext()) {
				Map<String, Object> row = result.next();
				for (String key : result.columns()) {
				 System.out.printf( "%s = %s%n", key, row.get( key ) );
				}				
			}
		}
		db.shutdown();
	}*/
	
	public static void main(String [] args)
	{
		//clearDatabase();
		//readNetFile(args[0]);
		javaDriverDemo();
		//javaNativeDemo(100, 0.2);

	}
}