from sys import argv


def read_edge_list(filename):
    nodeset= set([])
    edgelist = []
    with open(filename, 'r') as file_handle:
        for line in file_handle:
            if line[0] != '#':
                data = line.split('","')
                node_from = data[0] + '"'
                node_to = '"' + data[1].strip()
                nodeset.add(node_from)
                nodeset.add(node_to)
                edgelist.append([node_from, node_to])
    return nodeset, edgelist


def write_csv_nodes(nodes, file_nodes):
    with open(file_nodes, 'w') as file_handle:
        file_handle.write("NodeID\n")
        for node in nodes:
            file_handle.write('{0}\n'.format(node))



def write_csv_edges(edges, file_nodes):
    with open(file_nodes, 'w') as file_handle:
        file_handle.write("EdgeFrom,EdgeTo\n")
        for edge in edges:
            file_handle.write('{0},{1}\n'.format(edge[0], edge[1]))

script, input_file, output_file_nodes, output_file_edges = argv
nodes, edges = read_edge_list(input_file)
write_csv_nodes(nodes, output_file_nodes)
write_csv_edges(edges, output_file_edges)

