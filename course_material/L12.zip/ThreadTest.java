public class ThreadTest {
	public static final int STEPS = 100;
	public static final double MAX_AMOUNT = 1000;
	public static final int DELAY = 10;
	
	public static void main(String[] args) {
		Bank bank = new Bank(4, 100000);
		Thread task1, task2;
		task1 = new Thread(new Task(bank, 0, 1));
		task2 = new Thread(new Task(bank, 2, 3));
		task1.start();
		task2.start();
	}
}

class Task implements Runnable {
	public Task(Bank bank, int from, int to) {
		this.bank = bank;
		this.from = from;
		this.to = to;
	}
	
	@Override
	public void run() {
		try {
			for (int i = 0 ; i < ThreadTest.STEPS; i++) {
				double amount =  ThreadTest.MAX_AMOUNT * Math.random();
				this.bank.transfer(this.from, this.to, amount);
				Thread.sleep((int) (ThreadTest.DELAY * Math.random()));
			}
		}
		catch (InterruptedException e) {}
	}
	
	private Bank bank;
	private int from, to;
}