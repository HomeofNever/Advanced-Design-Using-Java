import java.util.*;

public class Interruptible {
	public static void main(String[] args) {
		Thread t1 = new Thread(new Runnable() {
		    public final int THRESHOLD = 100; // 100 1000000000
		    public final int LIMIT = 102;     // 102 1000000010
			public void run() {
			    Random rnd = new Random();
			    int val;
			    boolean done = false;
                try {
                	Thread.sleep(500);
                    while (!Thread.currentThread().isInterrupted() && !done) {
                    	val = rnd.nextInt(LIMIT);
                        if (val > THRESHOLD) {
                        	done = true;
                        }
                        System.out.printf("A random value of %d was obtained\n", val);
                    }
                }
                catch(InterruptedException e) {
                    System.out.printf("Thread was interrupted during sleep or wait.\n");
                }
                finally {
                    // cleanup, if required
                }
                System.out.printf("Thread running run() is done.\n");
            }
		});
		t1.start();

		try {
			t1.join(3000);
		}
		catch (InterruptedException e) {
			System.out.println("Joining was interrupted");
		}
		if (t1.isAlive()) {
			System.out.println("Timeout waiting the other thread to terminate.");
			System.out.println("Sendining an interrupt to another thread...");
			t1.interrupt();
		}
		System.out.printf("Thread running main() is done.\n");
	}
}
