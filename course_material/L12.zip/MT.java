public class MT {
	public static void main(String[] args) {
		System.out.println("Thread id of the current thread (runnnig main()) is " + 
			Thread.currentThread().getId());
		T1 t1 = new T1();
		t1.start(); // NOT t1.run(); !!!
		T2 t2 = new T2(200);
		Thread t3 = new Thread(t2);
		System.out.println("t3.getId() returns " + t3.getId());
		t3.start();
		/*try {
		    Thread.sleep(100);
		}
		catch (InterruptedException e) {
		    System.out.println("Thread was interrupted.");
		}*/
		System.out.println("Running from MT");
		try {
			t3.join();
		}
		catch (InterruptedException e) {
			System.out.println("Joining was interrupted");
		}
		System.out.printf("T2 thread is done with %d\n", t2.getVal());
	}
}

class T1 extends Thread {
	@Override
	public void run() {
        System.out.println("Starting T1");
		try {
		    Thread.sleep(3000);
		}
		catch (InterruptedException e) {
		    System.out.println("Thread was interrupted.");
		}		
		System.out.println("Running from T1");
		System.out.println("this.getId() returns " + this.getId());
		System.out.println("Thread id of the current thread (runnnig main()) is " + 
			Thread.currentThread().getId());
	}
}

class T2 implements Runnable {
	public T2(int val) {
		this.val = val;
	}
	public void run() {
		System.out.printf("%s - %d\n", "Running from T2", val);
		this.val = 100000;
	}
	public int getVal() { return this.val; }
	private int val;
}