import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import java.util.*;
import java.util.logging.*;

/**
 * @author kuzmik2
 *
 */
public class GUIUpdateDemo {

	/**
	 * @param args
	 * @throws InterruptedException 
	 */
	public static void main(String[] args) throws InterruptedException {
		GUIUpdateDemo demo = new GUIUpdateDemo();
		demo.scheduleGUI();
		demo.updateArray();
	}
	
	public void scheduleGUI() {
		EventQueue.invokeLater(() ->  {
	        JFrame frame = new GUIUpdateFrame(this);
	        frame.setTitle("Updateable Array Viewer");
	        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        frame.setVisible(true);
	    });
	}
	
	public void updateArray() throws InterruptedException {
		int row, col;
		Random rand = new Random();

		while (this.panel == null) Thread.sleep(1);
		while (!panel.isVisible()) ;
		while (panel.isVisible()) {
			row = rand.nextInt(data.length);
			col = rand.nextInt(data[row].length);
			data[row][col] = data[row][col] + 1;
			if (this.panel != null) {
				EventQueue.invokeLater(() ->  {
					this.panel.repaint();
			    });
			}
			Thread.sleep(10);
		}		
	}
	
	public int getRows() {
		return data.length;
	}
	
	public int getCols(int row) {
		return data[row].length;
	}
	
	public int getValue(int row, int col) {
		return data[row][col];
	}
	
	public void setPanel (JComponent panel) {
		this.panel = panel;
	}
	
	public JComponent getPanel() {
		return panel;
	}
	
	private int[][] data = new int[10][10];
	private JComponent panel = null;

}

class GUIUpdateFrame extends JFrame
{
   /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public GUIUpdateFrame(GUIUpdateDemo demo) {
	   this.demo = demo;

	   // get screen dimensions
      Toolkit kit = Toolkit.getDefaultToolkit();
      Dimension screenSize = kit.getScreenSize();
      int screenHeight = screenSize.height;
      int screenWidth = screenSize.width;

      // set frame width, height and let platform pick screen location
      setSize(screenWidth / 2, screenHeight / 2);
      setLocationByPlatform(true);
      
      JComponent arrayPanel = new ArrayPanel(demo);
      add(arrayPanel);
      pack();
   }
   private GUIUpdateDemo demo;
}

class ArrayPanel extends JComponent {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ArrayPanel(GUIUpdateDemo demo) {
		this.demo = demo;
		this.demo.setPanel(this);
		setPreferredSize(new Dimension(400, 400));
	}
	
	public void paintComponent(Graphics g) {
		final int ORIG_X = 10, ORIG_Y = 20, WIDTH = 30, HEIGHT = 30;
		Logger.getLogger("global").info(Integer.toString(Helper.sumArr(demo)));
		for (int i = 0; i < demo.getRows(); i++)
			for (int j = 0; j < demo.getCols(i); j++) {
				g.drawString(Integer.toString(demo.getValue(i, j)), ORIG_X + WIDTH * j, ORIG_Y + HEIGHT * i);
			}
	}
	
	private GUIUpdateDemo demo;
}

class Helper {
	public static int sumArr(GUIUpdateDemo demo) {
		int sum = 0;
		for (int i = 0; i < demo.getRows(); i++)
			for (int j = 0; j < demo.getCols(i); j++) {
				sum += demo.getValue(i, j);
			}
		return sum;
	}
}