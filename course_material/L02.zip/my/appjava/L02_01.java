package edu.rpi.cs.csci4963.u20.kuzmik2.lec02;

public class L02_01 {
  public static int mult(int a, int b) {
    return a * b;
  }
  
  public static void main(String[] args) {
  	  System.out.println("Hello from L02_01");
  }
}