package my;

public class L02_05 {
  public static int mult(int a, int b) {
    return a * b;
  }
   public static void main(String[] args) //throws FileNotFoundException, IOException
   {
   	   System.out.println("Hello from my.L02_05");
   }
}