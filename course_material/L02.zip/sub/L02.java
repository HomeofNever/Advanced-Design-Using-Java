package sub;

public class L02 {
	
   public static void main(String[] args) //throws FileNotFoundException, IOException
   {
   	   System.out.println("Hello from sub.L02");
   }
}