import java.util.*;
import java.io.*;
import javax.swing.*;
import my.appjava.*;
import my.*;

public class L02
{
   /** main()
   @param args - command line arguments
   */
   public static void main(String[] args) //throws FileNotFoundException, IOException
   {
   	   sub.L02 anL02;
   	   System.out.println("Hello from unnamed package L02");
   	   //System.out.printf("%s\n%s\n" , args[0], args[1]);
   	   System.out.println(L02_05.mult(5, 8));
   	   /*int i, j; // valid in Java
   	   j = 20;
   	   //System.out.println(i); // can't read uninitialized variable
   	   
   	   int k = 5; // declare and initialize in one line;
   	   i = j = 15;
   	   System.out.printf("%d %d\n", i, j);
   	   int f, g = 20;
   	   //System.out.printf("%d %d\n", f, g); // f is uninitialized 
   	   */
   	   
   	   //JOptionPane.showMessageDialog(null, "Hello, Welcome to Application Programming Using Java.");
   	   
   	   //final double π = 4.19;
   	   //   // int p = 5;
   	   
   	   //System.out.println("The value of π is " + π); // Comment
   	   //System.out.println("Another line");
   	   //System.out.println(5 + 3 + "5 is 5");
   	   //System.out.println("5 is 5" + 5 + 3);
   	   
   	   //double d = 15.23876876876D;
   	   //int precision = 3;
   	   //String foo = String.format("%." + precision + "f\n", d); // "%.9f"
   	   //System.out.println(foo);
   	   //System.out.printf("%5d\n", 4);
   	   
      /*String fileName;
      String line;
      Scanner in = new Scanner(System.in);
      System.out.print("Enter file name ");
      fileName = in.nextLine();
      System.out.print("How many times to read? ");
      int retries = in.nextInt();
      System.out.printf("File %s will be read %d times!\n", fileName, retries);*/
      
      /*Console cons = System.console();
      String username = cons.readLine("User name: ");
      char[] passwd = cons.readPassword("Password: ");  */
   	  
      //if (false) return;
      //System.exit(0); 	      	   

      //System.out.println("Beyond the end?");

   }
}
