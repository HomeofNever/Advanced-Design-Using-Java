package employee;

import java.time.*;
import employee.Employee;

public class EmployeeTest {
	public static void main(String[] args) {
		Employee em1 = new Employee();
		Employee em2 = new Employee("Eve", 200000.0, LocalDate.of(2019, 5, 29));
		//em1.name = "Trent ";
        em2.givePraise();
        em2.givePoorEval();
        System.out.println(em2);
        //em2.getEvals().setLength(0);
        /*em2.getEvals().setLength(0);
        em2.getEvals().append("Best employee of the month");*/
		em2.resetEval();
		System.out.println(em2);
	}
}

class AnotherTest{
	public static void main(String[] args) {
		Employee em = new Employee();
		System.out.println("AnotherTest");
	}
}