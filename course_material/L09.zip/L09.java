import java.util.*;

/**
* Demo code for Lecture 9
* @author Konstantin Kuzmin
* @version <b>1.0</b> rev. 0
*/

//enum Size { SMALL, MEDIUM, LARGE, EXTRA_LARGE };

enum Size {
	SMALL("S"), MEDIUM("M"), LARGE("L"), EXTRA_LARGE("XL");
	private Size(String abbr) {
		this.abbreviation = abbr;
	}
	public String getAbbreviation() {
		return this.abbreviation;
	}
	private String abbreviation;
};

public class L09
{
    public void L09() {
        System.out.println("In L09 method");
    }
    public L09() {
        System.out.println("In L09 constructor");
    }
   /**
   * main() method
   * @param args - command line arguments
   */
   public static void main(String[] args) // String... args
   {
   	   /*int x = 0, y = -7; // x = 5; x = 0;
   	   boolean b1 = x != 0 && 1 / x > x + y; // no division by 0
   	   //boolean b2 = x != 0 & 1 / x > x + y; // division by 0 !!!
   	   //System.out.printf("%b %b\n", b1, b2);
   	   System.out.printf("%b\n", b1);
   	   
   	   int n = -8;
   	   int fourthBitFromRight = (n & 0b1000) / 0b1000;
   	   System.out.printf("%s %s\n", String.format("%32s",
   	   	   Integer.toBinaryString(n)).replace(" ", "0"),
   	   	   String.format("%32s",
   	   	   	   Integer.toBinaryString(fourthBitFromRight)).replace(" ", "0"));
   	   
   	   int bits = Integer.toBinaryString(n).length();  // Should be 32 for ints
   	   // >> extends the sign (arithmetic shift)
   	   fourthBitFromRight = n << Integer.toBinaryString(n).length() - 4 >> bits - 1;
   	   System.out.printf("%s %s\n", String.format("%32s",
   	   	   Integer.toBinaryString(n)).replace(" ", "0"),
   	   	   String.format("%32s",
   	   	   	   Integer.toBinaryString(fourthBitFromRight)).replace(" ", "0"));
   	   
   	   // >>> fills with zeros (logical shift)
   	   fourthBitFromRight = n << Integer.toBinaryString(n).length() - 4 >>> bits - 1;
   	   System.out.printf("%s %s\n", String.format("%32s",
   	   	   Integer.toBinaryString(n)).replace(" ", "0"),
   	   	   String.format("%32s",
   	   	   	   Integer.toBinaryString(fourthBitFromRight)).replace(" ", "0"));
   	   
   	   System.out.printf("%d %d\n", 1 << 35, 1 << 3); // 35 % 32 == 3
   	   */
   	   
   	   
   	   
   	   
       L09 lec = new L09();
       //L09 lec01;
       //lec01.max(1.6, -5.9);  // Error!
       lec.L09();
       
       // Internally: new double[] { 1.6, -5.9, 1e103, 27e-3 }
       System.out.println(lec.max(1, 1.6, -5.9, 1e103, 27e-3));
       System.out.println(lec.max(1));
       lec.my();
   }
   
   /*public static double max(double[] values)
   {
   	   //double d = value[0];
   	   return Double.NEGATIVE_INFINITY;
   }*/
   public static double max(int i, double... values)
   {
       double largest = Double.NEGATIVE_INFINITY;
       //double d = values[0];
       for (double v : values) if (v > largest) largest = v;
       return largest;
    }

   public void my() {
       sz = Enum.valueOf(Size.class, "SMALL");
       sz = Size.MEDIUM;
       System.out.println(sz.toString());
       
       System.out.println(sz.getAbbreviation());
   }
   Size sz;
}
