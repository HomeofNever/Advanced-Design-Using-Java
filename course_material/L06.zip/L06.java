import java.util.*;
import java.math.*;
/**
* Demo code for Lecture 6
* @author Konstantin Kuzmin
* @version <b>1.0</b> rev. 0
*/
public class L06
{
   /**
   * main() method
   * @param args - command line arguments
   */
   public static void main(String[] args)
   {
   	   int n = 8;
   	   if (n == 7)
   	   	   System.out.println("Equal!");
   	       n++;
   	   System.out.println(n);
   	   {
   	   	   int k = 12;
		   //int n = 35; // Error!
		   System.out.printf("%d %d\n", n, k);
       }
       // k is not defined here
       // k = k + 1;
       // System.out.printf("%d %d\n", n, k);

       /*int x = 5, sign;
       // Use braces for clarity!
       sign = 1;
       if (x <= 0) { if (x == 0) sign = 0; } else sign = -1;
   	   System.out.println(sign);
   	   
   	   String cmp = x < 0 ? "negative" : "non-negative";
   	   System.out.printf("%d is %s\n", x, cmp);
   	   
   	   sign = x < 0 ? -1 : x == 0 ? 0 : 1;
   	   System.out.println(sign);*/

   	    
		Scanner in = new Scanner(System.in);
		/*final int BEST = 3; // add final
		System.out.print("Select an option (1, 2, 3, 4) ");
		int choice = in.nextInt();
		// Consider compiling with -Xlint:fallthrough if
		//   you want the compiler to catch the fallthrough behavior
		switch (choice)
		{
		case 1:  // 1, 2
			System.out.println("You chose 1");
			//choice++;
			//break;
		case 2:
		    System.out.println("You chose 2");
		    break;
		case BEST:
			System.out.println("You chose 3");
			break;
		case 4:
			System.out.println("You chose 4");
			break;
		default:
		// bad input
			System.out.println("You didn't make a valid selection");
			break;
		}*/
		
		/*System.out.print("Enter a number ");
		float choice = in.nextFloat();
		switch (choice)
		{
			case 1.0F:
				System.out.println("You chose 1");
				break;
			case 2.5D:
				System.out.println("You chose 2.5");
				break;
		}*/
			
		/*System.out.print("Enter your name ");
		String choice = in.nextLine();
		switch (choice)
		{
			case "Alice":
				System.out.println("Hello Alice");
				break;
			case "Bob":
				System.out.println("Hello Bob");
				break;
		}*/

	   /*for (;;) ;
	   int k = 0;
	   for (; k < 5; ++k) ;
	   for (int k = 0; k < 5; ) { ++k; }*/
	   /*int k, m;
   	   for (k = 0, m = 1; k < 5 && m < 3; ++k) {
   	   	   System.out.printf("%d %d\n", k, m);
   	   	   ++m;
   	   }
   	   k = k + 10;*/
   	   /*double m;
   	   int k;
   	   for (k = 0, m = 1.0; k < 5 && m < 3; ++k) {
   	   	   System.out.printf("%d %f\n", k, m);
   	   	   ++m;
   	   }*/

   	   //System.out.println(2.0 - 1.1);	
   	   /*for (double d = 0; d != 10; d += 0.1) {
   	       System.out.printf("%f\n", d);
   	       System.out.println(d);
   	   }*/
   	   /*for (double d = 0; d <= 1000; d += 0.1) {
   	       System.out.printf("%f\n", d);
   	   }*/
   	   /*int steps = 10000; // 10 / 0.1
   	   double d = 0.0D, inc = 0.1D;
   	   for (int i = 0; i < steps; ++i) {
   	   	   d += inc;
   	       System.out.printf("%f\n", d);
   	   }*/
   	   
   	   int val;
       //Scanner in = new Scanner(System.in);
   	   /*do {
   	   	   System.out.print("Enter an integer between 0 and 5 inclusive: ");
   	   	   val = in.nextInt();
   	   } while ( val < 0 || val > 5);*/

   	   /*System.out.print("Enter an integer between 0 and 5 inclusive: ");
   	   val = in.nextInt();
   	   while(val < 0 || val > 5) {
   	   	   System.out.print("Enter an integer between 0 and 5 inclusive: ");
   	   	   val = in.nextInt();
   	   }*/
   	   
   	   /*System.out.println("Primes:");
   	   int[] primes = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29};
   	   for (int num : primes) {
   	   	   num = num + 1;
   	   	   System.out.println(num);
   	   }
   	   System.out.println("=====================");
   	   for (int num : primes) {
   	   	   // num = primes[i];
   	   	   // primes[i]++;
   	   	   System.out.println(num);
   	   }*/
   	   
   	   /*int years = 1; 
   	   double interestRate = 0.015, balance = 0, payment = 100, goal = 1000;
   	   while (years <= 100 ) // && balance < goal
   	   {
   	      balance += payment;
   	      double interest = balance * interestRate / 100;
   	      balance += interest;
   	      if (balance < goal) {
   	      	  years++;
   	      }
   	   }
   	   System.out.printf("You need %d years to save %.2f or more\n", years, goal);*/
   	   
   	   /*while (years <= 100)
   	   {
   	     balance += payment;
   	     double interest = balance * interestRate / 100;
   	     balance += interest;
   	     if (balance >= goal) break;
   	     years++;
   	   }
   	   System.out.printf("You need %d years to save %.2f or more\n", years, goal);*/

   	   //read_data:
   	   /*int n0, sum = 0, count = 1;
   	   final int LIMIT = 100;
   	   read_data:
   	   while (true) {
   	   	   System.out.printf("Round %d starting\n", count);
   	   	   for (int i = 0; i < 5; ++i) {
   	   	   	   System.out.print("Enter a number such that sum is not exceeded ");
   	   	   	   n0 = in.nextInt();
   	   	   	   if (n0 < 0) {
   	   	   	      continue; // continue read_data;
   	   	   	   }
   	   	   	   sum += n0;
   	   	   	   //if (sum > LIMIT) {
   	   	   	   //   break read_data;
   	   	   	   //}
   	   	   	   System.out.printf("Current sum is %d\n", sum);

   	   	   	}
   	   	   	System.out.printf("Round %d ended\n", count);
   	   	   	count++;
   	   }*/
   	   
/*   	   int n1 = 1;
myLabel:
       {
       	   System.out.println("Inside the block");
           if (n1 == 15) break myLabel; // exits block
           System.out.println("At the end of the block");
       }
       System.out.println("Broken out of the block");
       
target:
       {
         if (true) break target; // goto!!!
         n1 = 25;
       }
       System.out.printf("Went to this line directly, n1 = %d\n", n1);*/
       
       /*BigInteger a = BigInteger.valueOf(100);
       BigInteger b = BigInteger.valueOf(400);
       BigInteger c = a.add(b); // c = a + b
       BigInteger d = c.multiply(b.add(BigInteger.valueOf(2))); // d = c * (b + 2)
       System.out.printf("d is %d\n", d);*/


   	   /*int x = 0, y = -7; // x = 5; x = 0;
   	   boolean b1 = x != 0 && 1 / x > x + y; // no division by 0
   	   //boolean b2 = x != 0 & 1 / x > x + y; // division by 0 !!!
   	   //System.out.printf("%b %b\n", b1, b2);
   	   System.out.printf("%b\n", b1);
   	   
   	   int n = -8;
   	   int fourthBitFromRight = (n & 0b1000) / 0b1000;
   	   System.out.printf("%s %s\n", String.format("%32s",
   	   	   Integer.toBinaryString(n)).replace(" ", "0"),
   	   	   String.format("%32s",
   	   	   	   Integer.toBinaryString(fourthBitFromRight)).replace(" ", "0"));
   	   
   	   int bits = Integer.toBinaryString(n).length();  // Should be 32 for ints
   	   // >> extends the sign (arithmetic shift)
   	   fourthBitFromRight = n << Integer.toBinaryString(n).length() - 4 >> bits - 1;
   	   System.out.printf("%s %s\n", String.format("%32s",
   	   	   Integer.toBinaryString(n)).replace(" ", "0"),
   	   	   String.format("%32s",
   	   	   	   Integer.toBinaryString(fourthBitFromRight)).replace(" ", "0"));
   	   
   	   // >>> fills with zeros (logical shift)
   	   fourthBitFromRight = n << Integer.toBinaryString(n).length() - 4 >>> bits - 1;
   	   System.out.printf("%s %s\n", String.format("%32s",
   	   	   Integer.toBinaryString(n)).replace(" ", "0"),
   	   	   String.format("%32s",
   	   	   	   Integer.toBinaryString(fourthBitFromRight)).replace(" ", "0"));
   	   
   	   System.out.printf("%d %d\n", 1 << 35, 1 << 3); // 35 % 32 == 3
   	   */
   }
}
