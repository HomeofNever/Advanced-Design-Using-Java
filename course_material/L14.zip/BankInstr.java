import java.util.concurrent.locks.*;
import java.util.logging.*;

/**
 * A bank with a number of bank accounts that uses locks for serializing access.
 * @version 1.30 2004-08-01
 * @author Cay Horstmann
 */
public class BankInstr
{
   /**
    * Constructs the bank.
    * @param n the number of accounts
    * @param initialBalance the initial balance for each account
    */
   public BankInstr(int n, double initialBalance)
   {
      accounts = new double[n];
      for (int i = 0; i < accounts.length; i++)
         accounts[i] = initialBalance;
      bankLock = new ReentrantLock();
      sufficientFunds = bankLock.newCondition();
   }

   /**
    * Transfers money from one account to another.
    * @param from the account to transfer from
    * @param to the account to transfer to
    * @param amount the amount to transfer
    */
   public void transfer(int from, int to, double amount, OverheadTime time) throws InterruptedException
   {
   	  long start;
   	  start = System.nanoTime();
      bankLock.lock();
      time.lockTime += System.nanoTime() - start;
      try
      {
      	 start = System.nanoTime(); 
         while (accounts[from] < amount) {
         	/*System.out.printf("Amount requested is %d but accounts[%d] = %d\n",
         		amount, from, accounts[from]);*/
            sufficientFunds.await();
         }
         time.waitTime += System.nanoTime() - start;
         accounts[from] -= amount;
         accounts[to] += amount;
         Logger.getGlobal().info(Thread.currentThread() + String.format("HELLO"));
         /*Logger.getGlobal().info(
         	 String.format(" %10.2f from %d to %d accounts[%d] = %d accounts[%d] = %d  Total Balance: %10.2f%n",
         	 amount, from, to, from, accounts[from], to, accounts[to], getTotalBalance(time)));*/    
         sufficientFunds.signalAll();
      }
      finally
      {
         bankLock.unlock();
      }
   }

   /**
    * Gets the sum of all account balances.
    * @return the total balance
    */
   public double getTotalBalance(OverheadTime time)
   {
   	  long start = System.nanoTime(); 
      bankLock.lock();
      time.lockTime += System.nanoTime() - start;
      try
      {
         double sum = 0;

         for (double a : accounts)
            sum += a;

         return sum;
      }
      finally
      {
         bankLock.unlock();
      }
   }

   /**
    * Gets the number of accounts in the bank.
    * @return the number of accounts
    */
   public int size()
   {
      return accounts.length;
   }

   private final double[] accounts;
   private Lock bankLock;
   private Condition sufficientFunds;
}

class OverheadTime {
	public long waitTime;
	public long lockTime;
}