import java.util.*;
import java.util.concurrent.*;
import java.util.logging.*;

public class ParallelBankTest {
	public static final int NACCOUNTS = 4; // 4 128
	public static final double NANO = 1000000000.0;
	public static final int NTRANSACTIONS = 2; // 2 20
	public static final double INITIAL_BALANCE = 1000;
	
	public static void main(String[] args) {
		BankInstr bank = new BankInstr(NACCOUNTS, INITIAL_BALANCE);

		List<Future> futures = new ArrayList<Future>();
		List<BankCounter> tasks = new ArrayList<BankCounter>();
		int num_threads = Runtime.getRuntime().availableProcessors();
		Logger.getGlobal().info(String.format("Number of cores: %d\n", num_threads));
		ExecutorService pool = Executors.newFixedThreadPool(num_threads);
		
		for (int i = 0; i < NACCOUNTS; i++) {
			int fromAccount = (int)(bank.size() * Math.random());
			BankCounter counter = new BankCounter(fromAccount, NTRANSACTIONS, bank);
			tasks.add(counter);
			futures.add(pool.submit(counter));
		}
		
		int sum = 0;
		try {
			for (Future f : futures) {
				sum += (Integer)f.get();
			}
		}
		catch (InterruptedException e) { }
		catch (ExecutionException e) { } 
			
		pool.shutdown();
		
		long lockTime = 0, waitTime = 0;
		for (BankCounter counter : tasks) {
			Logger.getGlobal().info(String.format("Thread %d time: %10.6f s%n", counter.getThreadId(), counter.getElapsedTime() / NANO));
			lockTime += counter.getThreadLockTime();
			waitTime += counter.getThreadWaitTime();
		}
		Logger.getGlobal().info(String.format("Blocked time: %10.6f s, waiting time: %10.6f s%n", lockTime / NANO, waitTime / NANO));

	}
}

class BankCounter implements Callable<Integer> {
	public static final double MAX_AMOUNT = 500;
	
	public BankCounter(int fromAccount, int count, BankInstr bank) {
		this.count = count;
		this. fromAccount = fromAccount;
		this.bank = bank;
	}
	
	public Integer call() {
		int transfers = 0;
		long start;
		start = System.nanoTime();
		this.threadId = Thread.currentThread().getId();
		try {
			while (count > 0) {
				int toAccount = (int) (bank.size() * Math.random());
				double amount = MAX_AMOUNT * Math.random();
				OverheadTime time = new OverheadTime();
				bank.transfer(fromAccount, toAccount, amount, time);
				transfers++;
				taskOverheadTime.waitTime += time.waitTime;
				taskOverheadTime.lockTime += time.lockTime;
				count--;
			}
		}
		catch (InterruptedException e) {
		}
		time = System.nanoTime() - start;
		return transfers;
	}
	
	public long getElapsedTime() {
		return time;
	}
	
	public long getThreadWaitTime() {
		return taskOverheadTime.waitTime;
	}

	public long getThreadLockTime() {
		return taskOverheadTime.lockTime;
	}
	
	public long getThreadId() {
		return this.threadId;
	}
	
	private int count, fromAccount;
	private BankInstr bank;
	private OverheadTime taskOverheadTime = new OverheadTime();
	private long threadId;
	private long time;
}

