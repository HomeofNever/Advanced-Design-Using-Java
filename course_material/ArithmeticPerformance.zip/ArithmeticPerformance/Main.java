import java.util.concurrent.TimeUnit;
import java.util.Random;
import java.math.BigDecimal;
import java.io.*;

class Main
{
    static final int ARRAY_SIZE = 100000;

    public static void main(String[] args) throws InterruptedException {
    	
        Random rd = new Random(); // creating Random object
        byte[] byteArr1 = new byte[ARRAY_SIZE];
        byte[] byteArr2 = new byte[ARRAY_SIZE];
        short[] shortArr1 = new short[ARRAY_SIZE];
        short[] shortArr2 = new short[ARRAY_SIZE];
        int[] intArr1 = new int[ARRAY_SIZE];
        int[] intArr2 = new int[ARRAY_SIZE];
        long[] longArr1 = new long[ARRAY_SIZE];
        long[] longArr2 = new long[ARRAY_SIZE];
        float[] floatArr1 = new float[ARRAY_SIZE];
        float[] floatArr2 = new float[ARRAY_SIZE];
        double[] doubleArr1 = new double[ARRAY_SIZE];
        double[] doubleArr2 = new double[ARRAY_SIZE];
        BigDecimal[] bigDecArr1 = new BigDecimal[ARRAY_SIZE];
        BigDecimal[] bigDecArr2 = new BigDecimal[ARRAY_SIZE];
        for (int i = 0; i < ARRAY_SIZE; i++) {
            byteArr1[i] = (byte)(rd.nextInt() % 128); // -127 .. 127 but the range for byte is -128 .. 127
            byteArr2[i] = (byte)(rd.nextInt() % 128);
            shortArr1[i] = (short)(rd.nextInt() % 32768); // -32767 .. 32767 but the range for byte is -32767 .. 32767
            shortArr2[i] = (short)(rd.nextInt() % 32768);
            intArr1[i] = rd.nextInt();
            intArr2[i] = rd.nextInt();
            longArr1[i] = rd.nextLong();
            longArr2[i] = rd.nextLong();
            floatArr1[i] = rd.nextFloat();
            floatArr2[i] = rd.nextFloat();
            doubleArr1[i] = rd.nextDouble();
            doubleArr2[i] = rd.nextDouble();
            bigDecArr1[i] = new BigDecimal(rd.nextDouble());
            bigDecArr2[i] = new BigDecimal(rd.nextDouble());
        }

        System.out.println("Random variables generated");

        long startTime;
        long endTime;
        long timeElapsed;

        int intTemp;

        String fileName = "performance.csv";
        String dataRow;

        FileWriter fileWriter = null;
        BufferedWriter bufferedWriter = null;
        try {
            // Assume default encoding.
            fileWriter = new FileWriter(fileName);

            // Always wrap FileWriter in BufferedWriter.
            bufferedWriter = new BufferedWriter(fileWriter);

            // Note that write() does not automatically
            // append a newline character.
            System.out.println("Datatype,Operation,#operations,Time");
            bufferedWriter.write("Datatype,Operation,#operations,Time");
            bufferedWriter.newLine();

			for (int size = 10000; size < ARRAY_SIZE; size += 10000 )
			{
				startTime = System.nanoTime();
				for (int i = 0; i < size; i++) {
					intTemp = intArr1[i] + intArr2[i];
				}
				endTime = System.nanoTime();
				timeElapsed = endTime - startTime;
				dataRow = String.format("int,+,%d,%d", size, timeElapsed);
				System.out.println(dataRow);
				bufferedWriter.write(dataRow);
				bufferedWriter.newLine();
				startTime = System.nanoTime();
				for (int i = 0; i < size; i++) {
					intTemp = intArr1[i] * intArr2[i];
				}
				endTime = System.nanoTime();
				timeElapsed = endTime - startTime;
				dataRow = String.format("int,*,%d,%d", size, timeElapsed);
				System.out.println(dataRow);
				bufferedWriter.write(dataRow);
				bufferedWriter.newLine();
				startTime = System.nanoTime();
				for (int i = 0; i < size; i++) {
					intTemp = intArr1[i] / intArr2[i];
				}
				endTime = System.nanoTime();
				timeElapsed = endTime - startTime;
				dataRow = String.format("int,/,%d,%d", size, timeElapsed);
				System.out.println(dataRow);
				bufferedWriter.write(dataRow);
				bufferedWriter.newLine();
		
				long longTemp;
				startTime = System.nanoTime();
				for (int i = 0; i < size; i++) {
					longTemp = longArr1[i] + longArr2[i];
				}
				endTime = System.nanoTime();
				timeElapsed = endTime - startTime;
				dataRow = String.format("long,+,%d,%d", size, timeElapsed);
				System.out.println(dataRow);
				bufferedWriter.write(dataRow);
				bufferedWriter.newLine();
				startTime = System.nanoTime();
				for (int i = 0; i < size; i++) {
					longTemp = longArr1[i] * longArr2[i];
				}
				endTime = System.nanoTime();
				timeElapsed = endTime - startTime;
				dataRow = String.format("long,*,%d,%d", size, timeElapsed);
				System.out.println(dataRow);
				bufferedWriter.write(dataRow);
				bufferedWriter.newLine();
				startTime = System.nanoTime();
				for (int i = 0; i < size; i++) {
					longTemp = longArr1[i] / longArr2[i];
				}
				endTime = System.nanoTime();
				timeElapsed = endTime - startTime;
				dataRow = String.format("long,/,%d,%d", size, timeElapsed);
				System.out.println(dataRow);
				bufferedWriter.write(dataRow);
				bufferedWriter.newLine();
		
				float floatTemp;
				startTime = System.nanoTime();
				for (int i = 0; i < size; i++) {
					floatTemp = floatArr1[i] + floatArr2[i];
				}
				endTime = System.nanoTime();
				timeElapsed = endTime - startTime;
				dataRow = String.format("float,+,%d,%d", size, timeElapsed);
				System.out.println(dataRow);
				bufferedWriter.write(dataRow);
				bufferedWriter.newLine();
				startTime = System.nanoTime();
				for (int i = 0; i < size; i++) {
					floatTemp = floatArr1[i] * floatArr2[i];
				}
				endTime = System.nanoTime();
				timeElapsed = endTime - startTime;
				dataRow = String.format("float,*,%d,%d", size, timeElapsed);
				System.out.println(dataRow);
				bufferedWriter.write(dataRow);
				bufferedWriter.newLine();
				startTime = System.nanoTime();
				for (int i = 0; i < size; i++) {
					floatTemp = floatArr1[i] / floatArr2[i];
				}
				endTime = System.nanoTime();
				timeElapsed = endTime - startTime;
				dataRow = String.format("float,/,%d,%d", size, timeElapsed);
				System.out.println(dataRow);
				bufferedWriter.write(dataRow);
				bufferedWriter.newLine();
		
				double doubleTemp;
				startTime = System.nanoTime();
				for (int i = 0; i < size; i++) {
					doubleTemp = doubleArr1[i] + doubleArr2[i];
				}
				endTime = System.nanoTime();
				timeElapsed = endTime - startTime;
				dataRow = String.format("double,+,%d,%d", size, timeElapsed);
				System.out.println(dataRow);
				bufferedWriter.write(dataRow);
				bufferedWriter.newLine();
				startTime = System.nanoTime();
				for (int i = 0; i < size; i++) {
					doubleTemp = doubleArr1[i] * doubleArr2[i];
				}
				endTime = System.nanoTime();
				timeElapsed = endTime - startTime;
				dataRow = String.format("double,*,%d,%d", size, timeElapsed);
				System.out.println(dataRow);
				bufferedWriter.write(dataRow);
				bufferedWriter.newLine();
				startTime = System.nanoTime();
				for (int i = 0; i < size; i++) {
					doubleTemp = doubleArr1[i] / doubleArr2[i];
				}
				endTime = System.nanoTime();
				timeElapsed = endTime - startTime;
				dataRow = String.format("double,/,%d,%d", size, timeElapsed);
				System.out.println(dataRow);
				bufferedWriter.write(dataRow);
				bufferedWriter.newLine();

				BigDecimal bigDecimalTemp;
				endTime = System.nanoTime();
				timeElapsed = endTime - startTime;
				dataRow = String.format("BigDecimal,+,%d,%d", size, timeElapsed);
				System.out.println(dataRow);
				bufferedWriter.write(dataRow);
				bufferedWriter.newLine();
				startTime = System.nanoTime();
				for (int i = 0; i < size; i++) {
					bigDecimalTemp = bigDecArr1[i].add(bigDecArr1[i]);
				}

				endTime = System.nanoTime();
				timeElapsed = endTime - startTime;
				dataRow = String.format("BigDecimal,*,%d,%d", size, timeElapsed);
				System.out.println(dataRow);
				bufferedWriter.write(dataRow);
				bufferedWriter.newLine();
				startTime = System.nanoTime();
				for (int i = 0; i < size; i++) {
					bigDecimalTemp = bigDecArr1[i].multiply(bigDecArr1[i]);
				}

				endTime = System.nanoTime();
				timeElapsed = endTime - startTime;
				dataRow = String.format("BigDecimal,/,%d,%d", size, timeElapsed);
				System.out.println(dataRow);
				bufferedWriter.write(dataRow);
				bufferedWriter.newLine();
				startTime = System.nanoTime();
				for (int i = 0; i < size; i++) {
					bigDecimalTemp = bigDecArr1[i].divide(bigDecArr1[i]);
				}
			}
            
            // Always close files.
            bufferedWriter.close();
        }
        catch(IOException ex) {
            System.out.println(
                "Error writing to file '" + fileName + "'");
        }
        finally {
        	try {
				// Always close files.
				if (bufferedWriter != null) bufferedWriter.close();
				if (fileWriter != null) fileWriter.close();
        	}
			catch (IOException ex) {
				System.out.println("Error closing streams");
			}
        }
    }
}