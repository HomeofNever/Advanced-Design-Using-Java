import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class LoginDialog extends JDialog {
    public LoginDialog(JFrame parent) {
        super(parent, "Login");
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                dispose();
                System.exit(0);
            }
        });
        getContentPane().add(createGUI());
        pack(); 
        setVisible(true);
    }
    public JTextField nameField, passwrdField;
    public JButton ok, cancel;
    private JPanel createGUI() {
        JPanel main = BoxLayoutUtils.createVerticalPanel();
        main.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));

        JPanel name = BoxLayoutUtils.createHorizontalPanel();
        JLabel nameLabel = new JLabel("Login:");
        name.add(nameLabel);
        name.add(Box.createHorizontalStrut(12));
        nameField = new JTextField(15);
        name.add(nameField);

        JPanel password = BoxLayoutUtils.createHorizontalPanel();
        JLabel passwrdLabel = new JLabel("Password:");
        password.add(passwrdLabel);
        password.add(Box.createHorizontalStrut(12));
        passwrdField = new JTextField(15);
        password.add(passwrdField);

        JPanel flow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        JPanel grid = new JPanel(new GridLayout(1, 2, 5, 0));
        ok = new JButton("OK");
        cancel = new JButton("Cancel");
        grid.add(ok);
        grid.add(cancel);
        flow.add(grid);

        BoxLayoutUtils.setGroupAlignmentX(
            new JComponent[] {
                name,
                password,
                main,
                flow
            }, Component.LEFT_ALIGNMENT);

        BoxLayoutUtils.setGroupAlignmentY(
            new JComponent[] {
                nameField,
                passwrdField,
                nameLabel,
                passwrdLabel
            },
            Component.CENTER_ALIGNMENT);

        GUITools.makeSameSize(new JComponent[] {
            nameLabel,
            passwrdLabel
        });

        GUITools.createRecommendedMargin(new JButton[] {
            ok,
            cancel
        });

        GUITools.fixTextFieldSize(nameField);
        GUITools.fixTextFieldSize(passwrdField);

        main.add(name);
        main.add(Box.createVerticalStrut(12));
        main.add(password);
        main.add(Box.createVerticalStrut(17));
        main.add(flow);

        return main;
    }
    // тестовый метод для проверки диалогового окна
    public static void main(String[] args) {
        new LoginDialog(new JFrame());
    }
}

class GUITools {
    public static void createRecommendedMargin(JButton[] buttons) {
        for (int i = 0; i < buttons.length; i++) {
            Insets margin = buttons[i].getMargin();
            margin.left = 12;
            margin.right = 12;
            buttons[i].setMargin(margin);
        }
    }
    public static void makeSameSize(JComponent[] components) {
        int[] sizes = new int[components.length];
        for (int i = 0; i < sizes.length; i++) {
            sizes[i] = components[i].getPreferredSize().width;
        }
        int maxSizePos = maximumElementPosition(sizes);
        Dimension maxSize = components[maxSizePos].getPreferredSize();
        for (int i = 0; i < components.length; i++) {
            components[i].setPreferredSize(maxSize);
            components[i].setMinimumSize(maxSize);
            components[i].setMaximumSize(maxSize);
        }
    }
    public static void fixTextFieldSize(JTextField field) {
        Dimension size = field.getPreferredSize();
        size.width = field.getMaximumSize().width;
        field.setMaximumSize(size);
    }
    private static int maximumElementPosition(int[] array) {
        int maxPos = 0;
        for (int i = 1; i < array.length; i++) {
            if (array[i] > array[maxPos]) maxPos = i;
        }
        return maxPos;
    }
}

class BoxLayoutUtils {
    public static void setGroupAlignmentX(JComponent[] cs, float alignment) {
        for (int i = 0; i < cs.length; i++) {
            cs[i].setAlignmentX(alignment);
        }
    }
    public static void setGroupAlignmentY(JComponent[] cs, float alignment) {
        for (int i = 0; i < cs.length; i++) {
            cs[i].setAlignmentY(alignment);
        }
    }
    public static JPanel createVerticalPanel() {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        return p;
    }
    public static JPanel createHorizontalPanel() {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
        return p;
    }
}