package application;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.*;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Separator;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import java.io.File;
import javafx.scene.chart.*;
import java.util.*;
import java.io.IOException;
import javafx.scene.control.Label;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.*;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Separator;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import java.io.File;
import javafx.scene.chart.*;
import java.util.*;
import java.io.IOException;

/**
 * Main controller for javafx application
 * 
 */
public class Controller implements Initializable{
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
	
		// TODO Auto-generated method stub
		
	}
	/**
	 * Closes window
	 * @param event
	 */
	public void Close(ActionEvent event) {
		Platform.exit();
		System.exit(0);
	}
	
	
	
	
	@FXML
	private Button run;
	
	@FXML
	public Label lab;	
	
	int count = 0;

	/**
	 * Represents the amount of times button is clicked
	 * @param event
	 */
	@FXML
	public void Tick(ActionEvent event) {
		count++;
		lab.setText("Count: "+count);
		
	}
	
	
	
	
	
	
}