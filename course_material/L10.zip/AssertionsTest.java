import java.io.*;
import java.util.*;

public class AssertionsTest {
	
	public void my2(int n) throws IllegalArgumentException, InvalidStudentRINException {
		System.out.println(n);
		if (n < 0) {
			throw new InvalidStudentRINException("66112222");
		}
		else {
			System.out.println("Success!");
		}
	}
	
	// requires: n >= 0
	public int my(int n) {
		//assert n >= 0 : "requires: n >= 0 is violated; n == " + n; // Check preconditions
		
		int m = 100;
		//Integer.parseInt("345r");
		try {
			Integer.parseInt("345r");
			return 20;
		}
		catch (NumberFormatException e) {
			System.out.println("Can't convert a String to an integer");
			//System.exit(0);
		    return 5;
		}
		catch (Exception e) {
		}
		finally {
			System.out.println("Inside finally block");
		    return 10;
		}
		//return 30;
	}
	
	public static void main(String[] args) throws FileNotFoundException, IOException { // throws FileNotFoundException  InvalidStudentRINException
		int n = 10; // 10; -1;
		//assert n > 0;
		/*try {
		    assert args.length > 0;
		}
		catch (Exception e) { // Exception  Throwable
			System.out.println("Exception caught");
		}*/

		//assert args[0].equals("123") : "First argument is not \"123\"";
		//assert n >= 0 : n;
		/*new AssertionsTest().my(n);
		System.out.println("Done");

		int i = -1; // 2; -1;
		assert i >= 0;
		if (i % 3 == 0) {
		}
		else if (i % 3 == 1) {
		}
		else { // (i % 3 == 2)
			//assert i % 3 == 2;
			//System.out.println("i % 3 == 2; in reality: i % 3 == " + (i % 3));
        }*/
		
        InputStream in = null;
		try {
			try {
			    in = new FileInputStream("input.txt");
			    System.out.println((char)in.read());
			}
			finally {
			    if (in != null) {
					try {
						in.close();
					}
					catch (IOException e) {
						e.printStackTrace();
					}
				}
		    }
	
		    Integer.parseInt("345r");
		    System.out.println("Successfully converted.");
		    String str = null;
		    str.charAt(0);
		}
		catch (Error e) { // Exception
		}
		/*catch (NumberFormatException e) {
		    System.out.println("Caught NumberFormatException");
		    System.out.println("Message: " + e.getMessage());
		    //System.exit(0);
		    return;
		}
		catch (IndexOutOfBoundsException e) {
		    System.out.println("Caught IndexOutOfBoundsException");
		    System.out.println("Message: " + e.getMessage());		
		}*/
		/*catch (NumberFormatException | IndexOutOfBoundsException e) {
			System.out.println("NumberFormatException | IndexOutOfBoundsException");
		}*/
		catch (Exception e) {
		    System.out.println("Caught Exception");
		    System.out.println("Message: " + e.getMessage());
		}
		finally {
		    System.out.println("Inside finally");
		    int a = 0;
		    double c, b = 0.0;
		    try {
			    c = b / a;
			    double d = Math.sqrt(-10);
			    if (c == Double.NaN) {
				    System.out.println("c is NaN");
			    }
			    if (((Double)d).isNaN()) {
				    System.out.println("d is NaN");
			    }
			    System.out.printf("Value of c is %f\n", c);
			    System.out.printf("Value of d is %f\n", d);
		    }
		    catch (ArithmeticException e) {
			    System.out.println("Do not divide by zero!");
		    }
		    /*if (in != null) {
		    	try {
		    	    in.close();
		    	}
		    	catch (IOException e) {
		    		e.printStackTrace();
		    	}
		    }*/
		}
		System.out.println("Recovered!");
		
        /*Exception ex = null;
        try
        {
            try
            {
                in = new FileInputStream("input.txt");
            }
            catch (FileNotFoundException e)
            {
                ex = e;
                throw e;
            }
        }
        finally
        {
            try
            {
            	if (in != null) {
                    in.close();
                }
            }
            catch (IOException e)
            {
               if (ex == null) throw e;
            }
        }*/
	
		// Works starting from Java 7
		try (Scanner sc = new Scanner(new FileInputStream("input.txt"))) // try re-using in
        {
            while (sc.hasNext())
                System.out.println(sc.next());
        }
        catch (Exception e) {
        	e.printStackTrace();
        }
        /*finally {
        	sc.close();
        }*/

		//System.out.println(new AssertionsTest().my(90));
		try {
		    new AssertionsTest().my2(-55);
		}
		catch (InvalidStudentRINException e) {
			e.printStackTrace();
			System.out.println(e.RIN);
		}
	}
}

class InvalidStudentRINException extends Exception {
	public String RIN;
	public InvalidStudentRINException(String RIN) {
		this.RIN = RIN;
	}
}

